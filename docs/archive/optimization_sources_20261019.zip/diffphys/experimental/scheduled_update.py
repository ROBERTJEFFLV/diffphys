"""Independent complete update with optional critical-region GC deferral."""
from __future__ import annotations

import copy
from dataclasses import replace
import math
from pathlib import Path
import time

import torch

from .dynamic_scheduling import defer_automatic_gc
from ..response_adjoints import backward_actor
from ..response_audit import json_report, parameter_changes
from ..response_noise import disturbance_report
from ..response_task import tensors_finite
from ..response_training import (_append, _sync, capture_rng, gradient_norm,
                                 optimizer_parameter_names, restore_rng,
                                 safe_global_clip, sample_training_scenarios)


def complete_scheduled_update(policy, optimizer, simulator, *, collector, scenes: int, horizon: int,
                    loss, groups, audit, progress: dict, history: Path,
                    extra_row: dict | None = None, defer_gc: bool = False, monitor=None) -> dict:
    """Include backup, sampling, metrics, clipping, Adam and real audit/history I/O.

    Setup/reset, periodic EVAL/checkpoints and optional after-timing numerical
    inspections belong to the caller. This is an experiment, not exact resume.
    """
    device = next(policy.parameters()).device
    _sync(device)
    start = time.perf_counter()
    before = (copy.deepcopy(policy.state_dict()), copy.deepcopy(optimizer.state_dict()), capture_rng())
    _sync(device)
    snapshot_done = time.perf_counter()
    record = backward = None
    gradients = {}
    seeds, sampling = [], {}
    try:
        initial, seeds = sample_training_scenarios(
            scenes // 4, 0, horizon=horizon, sampling="coverage128", device=device,
            dtype=next(policy.parameters()).dtype, sampling_report=sampling)
        sampling_done = time.perf_counter()
        optimizer.zero_grad(set_to_none=True)
        with defer_automatic_gc(defer_gc):
            if monitor is not None:
                monitor.stage = 'forward'
            record = collector(policy, simulator, initial, loss, horizon=horizon,
                               time_decay=1., group_config=groups)
            _sync(device)
            forward_done = time.perf_counter()
            if monitor is not None:
                monitor.stage = 'backward'
            backward = backward_actor(policy, simulator, record, loss, gradient_scale=.1)
            _sync(device)
            backward_done = time.perf_counter()
            if defer_gc:
                # Backward is complete and native Probe.finally has removed all hooks.
                # Drop only the finished graph before automatic cyclic GC can resume.
                record = replace(record, costs=record.costs.detach())
            if monitor is not None:
                monitor.stage = 'gc_resume'
        resumed = time.perf_counter()
        if monitor is not None:
            monitor.stage = 'optimizer'
        raw_norm = safe_global_clip(policy.parameters(), 10.)
        gradients = {name: None if p.grad is None else p.grad.detach().clone()
                     for name, p in policy.named_parameters()}
        optimizer.step()
        tensors = list(policy.parameters()) + [v for state in optimizer.state.values()
                                               for v in state.values() if torch.is_tensor(v)]
        if not tensors_finite(tensors):
            raise FloatingPointError("nonfinite Adam parameters or moments")
        changes = parameter_changes(policy, before[0])
        if not math.isfinite(changes["l2"]):
            raise FloatingPointError("nonfinite actual Actor parameter-step norm")
        _sync(device)
        optimizer_done = time.perf_counter()
    except BaseException as error:
        try:
            audit.record(update=progress["updates"]+1, before=before, policy=policy,
                         optimizer=optimizer, names=optimizer_parameter_names(policy, optimizer),
                         rng_after=capture_rng(), progress=progress,
                         sampling={"seeds": seeds, "report": sampling, "benchmark_attempt_index": 0},
                         gradients=gradients,
                         groups={"layout": None if record is None else record.group_balance,
                                 "gradient": None if backward is None else backward["group_gradient"]},
                         changes=None, failure=type(error).__name__ + ": " + str(error))
        finally:
            policy.load_state_dict(before[0])
            optimizer.load_state_dict(before[1])
            restore_rng(before[2])
            optimizer.zero_grad(set_to_none=True)
        raise
    if monitor is not None:
        monitor.stage = 'audit'
    try:
        audit_path = audit.record(update=progress["updates"]+1, before=before, policy=policy,
                                  optimizer=optimizer, names=optimizer_parameter_names(policy, optimizer),
                                  rng_after=capture_rng(), progress=progress,
                                  sampling={"seeds": seeds, "report": sampling, "benchmark_attempt_index": 0},
                                  gradients=gradients,
                                  groups={"layout": record.group_balance, "gradient": backward["group_gradient"]},
                                  changes=changes)
    except BaseException:
        policy.load_state_dict(before[0])
        optimizer.load_state_dict(before[1])
        restore_rng(before[2])
        optimizer.zero_grad(set_to_none=True)
        raise
    _sync(device)
    audit_done = time.perf_counter()
    progress["updates"] += 1
    if monitor is not None:
        monitor.stage = 'history'
    row = {"update": progress["updates"], "experiment": "fixed-checkpoint-update-benchmark",
           "train_seeds": seeds, "training_sampling": sampling, **record.metrics,
           "raw_gradient_norm": raw_norm, "gradient_scale": .1, "time_decay": 1.,
           "group_balance": json_report({k: v for k, v in record.group_balance.items() if k != "scene_group_ids"}),
           "group_gradient": json_report(backward["group_gradient"]),
           "parameter_changes": changes, "audit_capsule": audit_path,
           "gradient_entering_adam_norm": gradient_norm(policy.parameters()),
           "disturbances": disturbance_report(initial), **(extra_row or {})}
    row["production_style_update_seconds"] = time.perf_counter() - snapshot_done
    _append(history, row)
    end = time.perf_counter()
    timings = {"snapshot_seconds": snapshot_done-start,
               "sampling_host_seconds": sampling_done-snapshot_done,
               "forward_seconds": forward_done-sampling_done,
               "backward_seconds": backward_done-forward_done,
               "graph_release_and_gc_resume_seconds": resumed-backward_done,
               "optimizer_seconds": optimizer_done-resumed,
               "audit_seconds": audit_done-optimizer_done,
               "report_and_history_seconds": end-audit_done,
               "production_style_update_seconds": row["production_style_update_seconds"],
               "complete_update_seconds": end-start}
    return {"timings": timings, "record": record, "backward": backward,
            "initial": initial, "audit_path": audit_path, "row": row}
