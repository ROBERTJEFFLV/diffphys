"""Independent A/C/P continuous trainer with strict source-bound exact resume."""
from __future__ import annotations

from contextlib import contextmanager
import copy
from dataclasses import asdict, dataclass
import gc
import random
from pathlib import Path
import signal
import time
import traceback
from unittest.mock import patch
import weakref

import numpy as np
import torch

from ..env_raptor import ACTION_CONVENTION, RaptorSimulator, RaptorState
from ..response_adjoints import collect_rollout, backward_actor
from ..response_audit import AuditConfig, UpdateAudit
from ..response_groups import GroupBalanceConfig
from ..response_noise import DisturbanceConfig
from ..response_policy import ARCHITECTURE, ResponseMotorPolicy, ResponsePolicyConfig
from ..response_task import TaskLossConfig
from ..response_training import (ROOT, SOURCE_FILES, _append, _checkpoint, _recover_log,
                                atomic_json, atomic_torch, capture_rng, file_hash,
                                migrate_named_adam, model_hash, restore_rng,
                                sample_training_scenarios, source_hash)
from .compiled_physics import CompiledRaptorSimulator
from .dynamic_scheduling import GCEvents, collector_for, index_fill_rollout
from .strict_inductor import compiler_contract
from .scene_prefetch import PrefetchedSampler, process_memory

EXPERIMENT_SOURCES = ('diffphys/experimental/continuous_training.py',
                      'diffphys/experimental/continuous_update.py',
                      'diffphys/experimental/scene_prefetch.py',
                      'diffphys/experimental/compiled_physics.py',
                      'diffphys/experimental/strict_inductor.py',
                      'diffphys/experimental/dynamic_scheduling.py',
                      'tools/train_compiled_candidate.py',
                      'configs/compiled_candidate_acceptance.json',
                      'configs/compiled_prefetch_acceptance.json')


@dataclass(frozen=True)
class CandidateConfig:
    scheme: str = 'C'
    device: str = 'cuda'
    scenes: int = 2048
    horizon: int = 500
    updates: int = 200
    checkpoint_every: int = 50
    seed: int = 7
    bool_index_fill: bool = False

    def __post_init__(self):
        if self.scheme not in ('A', 'C', 'P') or self.device not in ('cpu', 'cuda'):
            raise ValueError('only A/C/P and cpu/cuda are supported')
        if self.scenes < 128 or self.scenes % 128 or min(self.horizon,self.updates,self.checkpoint_every) < 1:
            raise ValueError('positive updates/horizon/cadence and total scenes divisible by 128 required')


@contextmanager
def critical_gc(defer: bool):
    enabled = gc.isenabled()
    if defer:
        gc.disable()
    try:
        yield
    finally:
        if defer:
            (gc.enable if enabled else gc.disable)()


class TimedSampler:
    """Time the original blocking sampler and its unchanged RaptorState.to calls."""
    def __init__(self):
        self.last = {}

    def __call__(self, *args, **kw):
        transfer = 0.
        original = RaptorState.to

        def measured(state, device, dtype):
            nonlocal transfer
            begin = time.perf_counter()
            result = original(state, device, dtype)
            if torch.device(device).type == 'cuda':
                transfer += time.perf_counter()-begin
            return result

        begin = time.perf_counter()
        with patch.object(RaptorState, 'to', measured):
            result = sample_training_scenarios(*args, **kw)
        elapsed = time.perf_counter()-begin
        self.last = {'sampling_blocking_seconds':elapsed, 'sampling_to_cuda_seconds':transfer,
                     'sampling_cpu_seconds':elapsed-transfer,
                     'batch_wait_seconds':elapsed-transfer,
                     'batch_delivery_and_upload_seconds':transfer}
        return result


def runtime_binding(config: CandidateConfig, donor_sha: str) -> dict:
    return {'version':'continuous-compiled-candidate-v2','config':asdict(config),
            'production_source_sha256':source_hash(),
            'experimental_sources':{name:file_hash(ROOT/name) for name in EXPERIMENT_SOURCES},
            'initialization':{'donor_sha256':donor_sha,'model_and_named_adam':True,
                              'sampling_start':0,'exact_resume_of_donor':False},
            'loss':asdict(TaskLossConfig(.01,.01,25.)),
            'groups':asdict(GroupBalanceConfig(max_groups=128,min_scenarios=config.scenes//128,layout='coverage128')),
            'disturbances':asdict(DisturbanceConfig()),
            'physics':compiler_contract() if config.device == 'cuda' else 'cpu-native-test',
            'torch':str(torch.__version__),'cuda':torch.version.cuda,
            'gpu':torch.cuda.get_device_name() if config.device == 'cuda' else None,
            'cudnn':torch.backends.cudnn.version(),'tf32':False,'threads':1,
            'time_decay':1.,'gradient_scale':.1,'group_clip':1.,'global_clip':10.}


def memory(device: str) -> dict:
    rss = next(int(line.split()[1])*1024 for line in Path('/proc/self/status').read_text().splitlines()
               if line.startswith('VmRSS:'))
    return {'rss_bytes':rss,'cuda_allocated_bytes':torch.cuda.memory_allocated() if device == 'cuda' else 0,
            'cuda_reserved_bytes':torch.cuda.memory_reserved() if device == 'cuda' else 0,
            'cuda_peak_bytes':torch.cuda.max_memory_allocated() if device == 'cuda' else 0}


def run(config: CandidateConfig, work: Path, *, donor: Path | None = None,
        resume: Path | None = None, stop_after: int | None = None) -> dict:
    from .continuous_update import continuous_update
    if (donor is None) == (resume is None):
        raise ValueError('supply one experiment donor or a new candidate resume checkpoint')
    work = Path(work)
    if not resume and work.exists() and any(work.iterdir()):
        raise ValueError('nonempty run directory; choose a new directory')
    work.mkdir(parents=True,exist_ok=True)
    entry_gc = gc.isenabled()
    torch.set_num_threads(1)
    random.seed(config.seed)
    np.random.seed(config.seed)
    torch.manual_seed(config.seed)
    if config.device == 'cuda':
        torch.cuda.manual_seed_all(config.seed)
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    policy = ResponseMotorPolicy().to(config.device)
    optimizer = torch.optim.Adam(policy.parameters(),lr=3e-4)
    saved = torch.load(resume or donor,map_location='cpu',weights_only=True)
    donor_sha = saved['binding']['initialization']['donor_sha256'] if resume else file_hash(donor)
    binding = runtime_binding(config,donor_sha)
    if resume:
        if (saved.get('schema') != 'continuous-compiled-candidate-v2'
                or saved.get('binding') != binding
                or saved.get('next_update') != saved['progress'].get('sampling_index')):
            raise ValueError('resume requires identical source/config/runtime binding and sampling progress')
    elif (saved.get('architecture') != ARCHITECTURE or saved.get('policy_config') != asdict(policy.config)
          or saved.get('binding',{}).get('protocol',{}).get('environment',{}).get('action_convention') != ACTION_CONVENTION):
        raise ValueError('donor native B interface/motor convention mismatch')
    policy.load_state_dict(saved['model'])
    if model_hash(policy) != saved.get('model_sha256'):
        raise ValueError('checkpoint model digest mismatch')
    migrate_named_adam(optimizer,policy,saved['optimizer'],saved['optimizer_parameter_names'])
    progress = copy.deepcopy(saved['progress']) if resume else {
        'updates':0,'sampling_index':0,'status':'training','elapsed_seconds':0.,
        'initialization':binding['initialization']}
    if progress['updates'] != progress['sampling_index']:
        raise ValueError('inconsistent sampling progress')
    initial_rng = saved['rng'] if resume else capture_rng()
    for name in ['history.jsonl','timing.jsonl','gc.jsonl']:
        _recover_log(work/name,progress['updates'])
    audit = UpdateAudit(work,AuditConfig(history=max(201,config.updates+1)),evaluation_interval=50,
                        binding=binding,source_root=ROOT,source_files=(*SOURCE_FILES,*EXPERIMENT_SOURCES),
                        torch_writer=atomic_torch,json_writer=atomic_json)
    simulator = CompiledRaptorSimulator() if config.device == 'cuda' else RaptorSimulator()
    collector = collector_for(index_fill_rollout) if config.bool_index_fill else collect_rollout
    groups = GroupBalanceConfig(max_groups=128,min_scenarios=config.scenes//128,layout='coverage128')
    loss = TaskLossConfig(.01,.01,25.)
    sampler = None
    pending = None
    old_handlers = {}
    stop = []
    result = None
    monitor = GCEvents()
    segment_start_update = progress['updates']
    startup_begin = time.perf_counter()
    # Frozen startup compilation is separate; restore the exact saved RNG after it.
    with critical_gc(config.scheme in ('C', 'P')):
        initial,_ = sample_training_scenarios(config.scenes//4,progress['updates'],horizon=config.horizon,
                                              sampling='coverage128',device=config.device)
        warm = collector(policy,simulator,initial,loss,horizon=config.horizon,group_config=groups,time_decay=1.)
        backward_actor(policy,simulator,warm,loss)
        del warm,initial
    optimizer.zero_grad(set_to_none=True)
    restore_rng(initial_rng)
    startup_seconds = time.perf_counter()-startup_begin
    stats_start = dict(torch._dynamo.utils.counters['stats'])
    elapsed_before = progress.get('elapsed_seconds',0.)
    started = time.perf_counter()

    def sync():
        if config.device == 'cuda':torch.cuda.synchronize()

    def save(filename='latest.pt',cleanup=None):
        value = _checkpoint(policy,optimizer,progress,binding)
        value['schema'] = 'continuous-compiled-candidate-v2'
        if cleanup is not None:value['cleanup'] = cleanup
        atomic_torch(work/filename,value)

    def interrupted(signum,frame):
        stop.append(signum)

    for signum in [signal.SIGINT,signal.SIGTERM]:
        old_handlers[signum] = signal.signal(signum,interrupted)
    atomic_json(work/'running.json',{'pid':__import__('os').getpid(),'start_update':progress['updates']})
    cleanup = {}
    with monitor:
        try:
            sampler = (PrefetchedSampler(config.scenes,config.horizon,progress['updates'],config.updates,
                                         dtype=next(policy.parameters()).dtype)
                       if config.scheme == 'P' else TimedSampler())
            while progress['updates'] < config.updates:
                if stop or (stop_after is not None and progress['updates'] >= stop_after):
                    progress['status'] = 'interrupted' if stop else 'stopped'
                    break
                monitor.case,monitor.trial = config.scheme,progress['updates']
                monitor.stage = 'snapshot_and_sampling'
                sync()
                tick = time.perf_counter()
                if config.device == 'cuda':torch.cuda.reset_peak_memory_stats()
                counters_before = dict(torch._dynamo.utils.counters['stats'])
                result = continuous_update(policy,optimizer,simulator,collector=collector,
                                           scenes=config.scenes,horizon=config.horizon,loss=loss,groups=groups,
                                           audit=audit,progress=progress,history=work/'history.jsonl',
                                           defer_gc=config.scheme in ('C', 'P'),monitor=monitor,sampler=sampler,
                                           index_fill=config.bool_index_fill)
                monitor.stage = 'release'
                probe = result['record'].probe
                assert probe._closed and not probe._payloads and not probe._tensor_handles
                weak_probe,weak_record = weakref.ref(probe),weakref.ref(result['record'])
                timing = result['timings']
                del probe,result
                result = None
                optimizer.zero_grad(set_to_none=True)
                sync()
                assert weak_probe() is None and weak_record() is None
                progress['elapsed_seconds'] = elapsed_before+time.perf_counter()-started
                if progress['updates'] % config.checkpoint_every == 0:
                    monitor.stage = 'checkpoint'
                    save()
                row = {'update':progress['updates'],**timing,**sampler.last,**memory(config.device),
                       **(sampler.worker.memory() if config.scheme=='P' else
                          {'combined_rss_bytes':memory(config.device)['rss_bytes'],
                           'combined_pss_bytes':process_memory(__import__('os').getpid())['pss_bytes']}),
                       'compiler_before':counters_before,'compiler_after':dict(torch._dynamo.utils.counters['stats'])}
                events,monitor.events = monitor.events,[]
                _append(work/'gc.jsonl',{'update':progress['updates'],'events':events})
                del events
                row['cycle_seconds'] = time.perf_counter()-tick
                _append(work/'timing.jsonl',row)
                print({'scheme':config.scheme,'update':progress['updates'],'seconds':round(row['cycle_seconds'],4),
                       'sampling_cpu_s':round(row['sampling_cpu_seconds'],4)},flush=True)
            else:
                progress['status'] = 'update_budget'
        except BaseException as error:
            progress['status'] = 'failed'
            progress['error'] = type(error).__name__+': '+str(error)
            (work/'error.txt').write_text(''.join(traceback.format_exception(error)))
            traceback.clear_frames(error.__traceback__)
            pending = error.with_traceback(None)
        finally:
            if result is not None and result['record'].probe is not None:
                result['record'].probe.close()
            result = None
            optimizer.zero_grad(set_to_none=True)
            if config.scheme == 'P' and sampler is not None:
                try:
                    sampler.worker.close()
                except BaseException as error:
                    if pending is None:
                        pending = error
                        progress['status'] = 'failed'
                cleanup.update(worker_closed=sampler.worker.closed,
                               worker_close_seconds=sampler.worker.close_seconds,
                               worker_pid=sampler.worker.pid)
            (gc.enable if entry_gc else gc.disable)()
            monitor.stage = 'final_cleanup'
            drain = time.perf_counter()
            collected = gc.collect()
            sync()
            cleanup = {**cleanup,'gc_enabled':gc.isenabled(),'entry_gc_enabled':entry_gc,
                       'closed_probes':all(not m._forward_hooks for m in policy.modules()),
                       'gc_collected':collected,'drain_seconds':time.perf_counter()-drain,**memory(config.device)}
            progress['elapsed_seconds'] = elapsed_before+time.perf_counter()-started
            save('failure.pt' if pending else 'latest.pt',cleanup)
            _append(work/'gc.jsonl',{'update':progress['updates'],'events':monitor.events})
            for signum,handler in old_handlers.items():signal.signal(signum,handler)
    total = time.perf_counter()-started
    summary = {'scheme':config.scheme,'start_update':segment_start_update,'end_update':progress['updates'],
               'status':progress['status'],'startup_seconds':startup_seconds,'training_seconds_including_final_io_gc':total,
               'compiler_start':stats_start,'compiler_end':dict(torch._dynamo.utils.counters['stats']),
               'cleanup':cleanup,'binding':binding}
    atomic_json(work/f'segment_{segment_start_update:04d}_{progress["updates"]:04d}.json',summary)
    if pending:raise pending
    return summary
