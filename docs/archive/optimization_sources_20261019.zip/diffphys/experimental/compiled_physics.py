"""Compile one original RK4 step; never compile the Actor or rollout loop.

This is an independent experimental backend. All
equations, pulse lookup and state/history updates come from the original bound
method. AOTAutograd differentiates that same region. Compiler errors propagate.
"""
from __future__ import annotations

from collections.abc import Callable

import torch

from ..env_raptor import RaptorParams, RaptorSimulator, RaptorState


class CompiledRaptorSimulator(RaptorSimulator):
    def __init__(self, params: RaptorParams = RaptorParams(), *,
                 backend: str | Callable = "compiled", options: dict | None = None):
        super().__init__(params)  # Keep quaternion rotation inside this graph.
        physics_step = super().step
        if backend == "compiled":
            if options:
                raise ValueError("compiled physics fixes its numerical compiler options")
            from .strict_inductor import strict_inductor
            backend = strict_inductor
        compiler_options = {"triton.cudagraphs": False, **(options or {})} if backend == "inductor" else options
        self._compiled_step = torch.compile(physics_step, backend=backend,
                                            fullgraph=True, dynamic=True,
                                            options=compiler_options)

    def step(self, state: RaptorState, action: torch.Tensor) -> RaptorState:
        # Keep the existing public validation error outside Dynamo's exception wrapping.
        if action.shape != state.motor.shape or action.device != state.motor.device or action.dtype != state.motor.dtype:
            raise ValueError("action must match rotor state [batch,4], dtype and device")
        return self._compiled_step(state, action)
