"""Opt-in numerical experiments, excluded from the production training path."""
from __future__ import annotations
