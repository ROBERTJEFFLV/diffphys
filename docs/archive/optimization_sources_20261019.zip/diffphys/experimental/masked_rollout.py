"""Independent fixed-batch scheduling experiment; production stays compacted."""
from __future__ import annotations

from contextlib import nullcontext
from dataclasses import fields
import math

import torch

from ..env_raptor import RaptorState
from ..response_adjoints import METRIC_CHUNK, RolloutRecord
from ..response_grad_probe import GroupGradientProbe
from ..response_groups import GroupBalanceConfig, group_gradient_coefficients, physics_group_layout
from ..response_task import (FlightStatistics, ResponseClosedLoopState, TaskTrajectory,
                            _decay_closed_state, initialize, observation,
                            step_cost_components, uniform_scene_weights)


def _masked_merge(before, after, active: torch.Tensor):
    return type(before)(**{
        field.name: (old if old is new else torch.where(
            active.reshape((len(active),) + (1,) * (old.ndim - 1)), new, old))
        for field in fields(before)
        for old, new in [(getattr(before, field.name), getattr(after, field.name))]
    })


def masked_rollout(policy, simulator, initial, steps: int, *, time_decay: float = 0.,
                   actor_probe=None, record_observations: bool = True) -> TaskTrajectory:
    if not math.isfinite(time_decay) or time_decay < 0:
        raise ValueError("time_decay must be finite and non-negative")
    if steps < 1:
        raise ValueError("rollout must contain physical transitions")
    if abs(simulator.params.dt - policy.config.dt) > 1e-12:
        raise ValueError("training and deployment dt must agree")
    closed = initialize(policy, initial) if isinstance(initial, RaptorState) else initial
    if (closed.physical.noise_tape.shape[1] > 1
            and int(closed.physical.step_index.max()) + steps >= closed.physical.noise_tape.shape[1]):
        raise ValueError("noise tape too short: sample scenarios for the full requested horizon")
    initial_physical = closed.physical
    observations = [observation(closed.physical)] if record_observations else []
    columns = {name: [] for name in ("actions", "positions", "velocities", "omegas",
                                    "action_deltas", "omega_deltas", "valid", "pre_positions",
                                    "pre_orientations", "post_orientations")}
    active = ~simulator.terminated(closed.physical)
    indices = torch.arange(len(active), device=active.device)
    live = closed
    decay = time_decay > 0 and torch.is_grad_enabled()
    rho = closed.physical.position.new_tensor(math.exp(-time_decay * simulator.params.dt))
    one = torch.ones_like(rho)
    for step in range(steps):
        if decay:
            # Match the original all-dead conditional without a host scalar read.
            effective_rho = torch.where(active.any(), rho, one)
            # Full/candidate aliases are parallel decay edges, exactly as in compaction.
            closed = _decay_closed_state(closed, effective_rho)
            live = _decay_closed_state(live, effective_rho)
        current_observation = observation(closed.physical)
        before = closed.physical
        if actor_probe is not None:
            actor_probe.begin_step(indices)
        output = policy(current_observation, live.policy)
        candidate = simulator.step(live.physical, output.action)
        action = torch.where(active[:, None], output.action, before.previous_action)
        closed = ResponseClosedLoopState(_masked_merge(before, candidate, active),
                                        _masked_merge(closed.policy, output.next_state, active))
        live = ResponseClosedLoopState(_masked_merge(live.physical, candidate, active),
                                      _masked_merge(live.policy, output.next_state, active))
        values = (action, closed.physical.position, closed.physical.velocity,
                  closed.physical.omega, action - before.previous_action,
                  closed.physical.omega - before.omega, active,
                  before.position, before.orientation, closed.physical.orientation)
        for name, value in zip(columns, values):
            columns[name].append(value)
        active = active & ~simulator.terminated(candidate)
        if record_observations:
            observations.append(observation(closed.physical))
    return TaskTrajectory(end=closed,
                          observations=torch.stack(observations) if record_observations else None,
                          initial=initial_physical,
                          **{name: torch.stack(values) for name, values in columns.items()})


def collect_masked_rollout(policy, simulator, initial, config, *, horizon: int = 500,
                           time_decay: float = 1.,
                           group_config: GroupBalanceConfig = GroupBalanceConfig()):
    """Original chunked objective/statistics/probe, with only scheduling replaced."""
    if horizon < 1:
        raise ValueError("horizon must be positive")
    closed = initialize(policy, initial)
    statistics = FlightStatistics(initial, horizon, config)
    probe = (GroupGradientProbe(policy, *physics_group_layout(initial, group_config))
             if group_config.backward_backend == "probe" else None)
    chunks = []
    try:
        with probe.capture() if probe is not None else nullcontext():
            for start in range(0, horizon, METRIC_CHUNK):
                trace = masked_rollout(policy, simulator, closed, min(METRIC_CHUNK, horizon-start),
                                       time_decay=time_decay, actor_probe=probe,
                                       record_observations=False)
                components = step_cost_components(trace, config, start=start, horizon=horizon)
                chunks.append(sum(components.values()))
                statistics.add(trace, start, components=components)
                closed = trace.end
        costs = torch.cat(chunks).sum(0)
        if not bool(torch.isfinite(costs).all()):
            raise FloatingPointError("nonfinite full-horizon costs")
        weights = uniform_scene_weights(costs)
        coefficients, report = group_gradient_coefficients(weights, initial, group_config)
        return RolloutRecord(costs, weights, statistics.finish(costs.detach(), weights),
                             coefficients, report, group_config, config, probe)
    except BaseException:
        if probe is not None:
            probe.close()
        raise
