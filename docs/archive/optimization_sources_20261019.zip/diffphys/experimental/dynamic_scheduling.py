"""Isolated bool-fill substitution and scoped automatic cyclic-GC deferral."""
from __future__ import annotations

from contextlib import contextmanager
import gc
import inspect
import linecache
from types import FunctionType
from time import perf_counter_ns

from ..response_adjoints import collect_rollout
from ..response_task import rollout


def _index_fill_variant():
    original = inspect.getsource(rollout)
    statement = 'active[indices] = True'
    if original.count(statement) != 1:
        raise RuntimeError('review original rollout before rebuilding bool-fill experiment')
    source = original.replace(statement, 'active.index_fill_(0, indices, True)')
    filename = '<diffphys.experimental.index_fill_rollout>'
    linecache.cache[filename] = (len(source), None, source.splitlines(keepends=True), filename)
    namespace = dict(rollout.__globals__)
    exec(compile(source, filename, 'exec'), namespace)
    return namespace['rollout']


index_fill_rollout = _index_fill_variant()


def collector_for(rollout_function):
    """Use the original collector bytecode with an isolated rollout binding."""
    collector = FunctionType(collect_rollout.__code__,
                             {**collect_rollout.__globals__, 'rollout': rollout_function},
                             collect_rollout.__name__, collect_rollout.__defaults__,
                             collect_rollout.__closure__)
    collector.__kwdefaults__ = collect_rollout.__kwdefaults__
    return collector


@contextmanager
def defer_automatic_gc(defer: bool):
    """Caller releases completed graphs before leaving; automatic GC resumes normally."""
    enabled = gc.isenabled()
    if defer and enabled:
        gc.disable()
    try:
        yield
    finally:
        if defer and enabled:
            gc.enable()


class GCEvents:
    """Record collections without forcing them or altering thresholds."""
    def __init__(self):
        self.stage = 'setup'
        self.case = None
        self.trial = None
        self.events = []
        self.starts = {}

    def callback(self, phase, info):
        generation = info['generation']
        if phase == 'start':
            self.starts[generation] = (perf_counter_ns(), self.stage)
        else:
            start, stage = self.starts.pop(generation)
            end = perf_counter_ns()
            self.events.append({'case': self.case, 'trial': self.trial, 'stage': stage, 'generation': generation,
                                'start_ns': start, 'end_ns': end,
                                'duration_ms': (end-start)/1e6,
                                'collected': info['collected'],
                                'uncollectable': info['uncollectable']})

    def __enter__(self):
        gc.callbacks.append(self.callback)
        return self

    def __exit__(self, *exc):
        gc.callbacks.remove(self.callback)
