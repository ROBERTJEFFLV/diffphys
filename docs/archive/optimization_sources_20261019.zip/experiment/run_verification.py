"""Wait for performance runs to finish; then verify without spending optimizer budget."""
import json
from pathlib import Path
import subprocess
import time

OUT=Path('reports/cpu_prefetch_20261019')
PYTHON='/tmp/diffphys-cuda-venv/bin/python'
while True:
    try:
        status=json.loads((OUT/'progress.json').read_text())
    except (FileNotFoundError,json.JSONDecodeError):
        time.sleep(1);continue
    if status.get('failed'):raise SystemExit('performance driver failed')
    if status.get('active') is None and len(status.get('completed',[]))==4:break
    time.sleep(1)
commands=[('offline',[PYTHON,'tools/verify_cpu_prefetch.py','--root',str(OUT)]),
          ('pytest_cuda',[PYTHON,'-m','pytest','-q','tests/test_continuous_candidate.py',
                          'tests/test_scene_prefetch.py','tests/test_dynamic_scheduling.py',
                          'tests/test_masked_rollout.py','tests/test_training_benchmark.py','tests/test_schedule_profile.py']),
          ('performance',[PYTHON,str(OUT/'analyze_performance.py')])]
for label,command in commands:
    with (OUT/(label+'.log')).open('w') as log:
        done=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    print({'label':label,'returncode':done.returncode},flush=True)
    if done.returncode:raise SystemExit(done.returncode)
