from pathlib import Path
import json
import statistics

root=Path('reports/cpu_prefetch_20261019')
p=json.loads((root/'performance_summary.json').read_text())
c,q,s=[p['cases'][name] for name in ['C','P','P_split']]
table=[]
for name,v in [('C serial',c),('P prefetch',q),('P 50 + fresh resume50',s)]:
    table.append(f"| {name} | {v['full_process_wall_seconds']:.3f} s | {v['training_seconds_including_worker_start_close_final_io_gc']:.3f} s | {v['frozen_compiler_startup_seconds']:.3f} s | {v['cycle_seconds']['median']:.4f} s | {v['cycle_seconds']['p90']:.4f} s | {v['cycle_seconds']['p99']:.4f} s | {v['cycle_seconds']['max']:.4f} s |")
fields=[]
for label,key in [('CPU generation','sampling_cpu_seconds'),('Main wait, including first batch','batch_wait_seconds'),('Delivery + unchanged blocking upload','batch_delivery_and_upload_seconds')]:
    fields.append(f"| {label} | {c[key]['median']:.6f} s | {q[key]['median']:.6f} s | {c[key]['sum']:.6f} s | {q[key]['sum']:.6f} s |")
mi=lambda xs:[round(x/2**20,2) for x in xs]
state=json.loads((root/'state_chain_comparison.json').read_text())
text=f'''## Measured result

**P passes this bounded numerical/resume acceptance.** Full process wall falls
from **{c['full_process_wall_seconds']:.3f} s to {q['full_process_wall_seconds']:.3f} s**,
a **{100*p['C_to_P_full_process_wall_reduction']:.2f}% elapsed-time reduction**
({c['full_process_wall_seconds']/q['full_process_wall_seconds']:.3f}x throughput),
including imports/compiler warmup, worker startup/first batch and shutdown,
normal audit/checkpoints and final cleanup. Production remains unchanged.

| Chain, 100 actual updates each | Full process wall | Training incl. worker start/close + final I/O/GC | Frozen compiler startup | Cycle median | p90 | p99 | Max |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
'''+ '\n'.join(table)+f'''

The training-only total decreases **{100*p['C_to_P_training_total_reduction']:.2f}%**.
Worker creation is inside that timer, after frozen compiler stabilization.
P's first update is the slowest because it includes first-batch wait; it is
not discarded. P's charged worker shutdown takes **{q['worker_close_seconds']:.6f} s**;
the split chain's two shutdowns total **{s['worker_close_seconds']:.6f} s**.
The split chain incurs two full process/compiler starts and first batches,
so it is a resume-correctness comparison rather than an additional paired
steady-state speed estimate. Its entire two-process cost is retained above.

| Stage | C median | P median | C sum /100 | P sum /100 |
| --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(fields)+f'''

P first-batch wait is **{q['first_batch_wait_seconds']['1']:.6f} s**. The other
99 batch waits total **{q['batch_wait_after_first_per_segment']['sum']:.9f} s**;
median **{q['batch_wait_after_first_per_segment']['median']*1e6:.2f} microseconds**,
maximum **{q['batch_wait_after_first_per_segment']['max']*1e6:.2f} microseconds**.
The worker still spends roughly 0.25 s generating each batch, but its result
is ready before the GPU training process needs it. Removing serial generation
wait saves a measured **{p['wait_seconds_removed_including_first']:.3f} s**, after
charging the first batch. Delivery/upload is slightly slower and is retained
in the measured total. Background-thread IPC work is also charged to wall time.

All ten corresponding ten-update blocks are faster with P; block reductions
range **{min(b['elapsed_reduction'] for b in p['matched_ten_update_blocks'])*100:.2f}%–{max(b['elapsed_reduction'] for b in p['matched_ten_update_blocks'])*100:.2f}%**,
including first-batch cost in block 1. These are correlated blocks within one
C-then-P process pair, not independent repetitions or a confidence interval.
The approved budget did not include repeated pairs or reversed run ordering.

The earlier 11.87% ideal bound used the previous 200-update workload and assumed
other stage timings stayed fixed. Here forward+backward totals also differ:
C **{c['forward_seconds']['sum']+c['backward_seconds']['sum']:.3f} s**, P
**{q['forward_seconds']['sum']+q['backward_seconds']['sum']:.3f} s**. Thus the measured
12.70% training reduction is not all attributed to removed sampling wait.
This experiment does not separate GPU clock effects, host submission timing
and other run-to-run variation. It establishes overlapped preparation and lower
actual elapsed time in this bounded run, not a revised theoretical ceiling.

### Exact learning and memory

All 300 actual update capsules pass raw-byte checks of every input/output
Actor/Adam/main RNG state, sampling seed/report, group/clipping report, gradient
entering Adam and parameter-change metric. Each chain has 100 nonzero parameter
updates and exactly sampling indices 0..99. Named Adam advances from donor
step 78,950 to 79,050. The saved split midpoint and fresh-process final result
match the uninterrupted chain. Final Actor SHA256:
`{state['final_model_sha256']}`.

CPU batches at indices 0/1/49/50/99 are identical in every dataclass tensor field,
all noise/rotation/pulse tapes, order, seeds and report, with unchanged main RNG.
Frozen H500 replays at updates **1/50/51/100** pass byte equality of initial state,
all captured step/trajectory/recurrent/history/active/termination values, raw
128-group gradients, clipping and final gradients; final gradients equal the
actual training audits too. No thresholds are relaxed. Numerical comparisons
run outside the timing process and call no Adam.

There are exactly four Dynamo graphs after each frozen startup and **zero new
graph compilations during all 300 learning updates**. GC remains deferred over
the same forward/backward region for both C and P; neither has GC callbacks
inside forward/backward. Normal/end-of-run collection costs remain charged.

Post-release CUDA live allocation is **19,339,264 bytes** at every boundary in
all three chains. P's combined parent/worker PSS ten-update medians, in MiB, are
`{mi(q['combined_pss_bytes']['ten_update_block_medians'])}`;
C's are `{mi(c['combined_pss_bytes']['ten_update_block_medians'])}`.
P worker RSS medians are
`{mi(q['worker_rss_bytes']['ten_update_block_medians'])}` MiB.
This is a bounded additional CPU runtime/cache/batch footprint, with allocator
warming and fluctuations rather than a sustained rising sequence. Combined
RSS ranges {q['combined_rss_bytes']['min']/2**20:.1f}–{q['combined_rss_bytes']['max']/2**20:.1f} MiB;
combined PSS ranges {q['combined_pss_bytes']['min']/2**20:.1f}–{q['combined_pss_bytes']['max']/2**20:.1f} MiB.
There is no claim of constant RSS or unlimited-run memory stability.

Each uninterrupted P run uses one worker PID; the resumed chain uses a new
worker PID after restart. All delivered batches report CUDA uninitialized,
intra-op threads=1 and inter-op threads=20 matching the parent. All actual
workers are joined and gone at exit. Tests additionally cover wrong consumption
index, duplicate outstanding submission, sampler exception and continued use,
unused-work shutdown, real SIGINT, forward/backward exceptions and direct
KeyboardInterrupt with GC initially enabled/disabled. GC restores its entry
state; Probe hooks/payloads and failed-update learning state are cleaned up.

Fresh verification: **530 CPU tests passed, 24 skipped**; **45 CUDA-environment
focused tests passed**. The real performance driver and offline verifier both
exit zero. Production source SHA256 remains
`0965252f0b69a6d9f2a755d9ad2dafae2f2ac20e9503b58736f903414fe8af61`;
the original `best.pt` and `tests/core_contract.json` are unchanged.

'''
pth=Path('docs/cpu_prefetch.md')
body=pth.read_text()
needle='## Implementation and numerical boundary'
assert '## Measured result' not in body
pth.write_text(body.replace(needle,text+needle))
