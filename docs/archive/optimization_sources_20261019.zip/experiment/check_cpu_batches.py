"""Real full-size CPU boundary verification; no optimizer or CUDA context."""
from dataclasses import fields
import gc
import hashlib
import json
import time
from pathlib import Path
import torch
from diffphys.experimental.scene_prefetch import ScenePrefetch
from diffphys.response_training import capture_rng, sample_training_scenarios, atomic_json
from tools.verify_compiled_continuity import exact


def main():
    torch.set_num_threads(1)
    before = capture_rng()
    worker = ScenePrefetch(512, horizon=500, threads=1)
    results = []
    try:
        for index in [0,1,49,50,99]:
            worker.submit(index)
            actual, seeds, report, stats = worker.take(index)
            expected_report = {}
            expected, expected_seeds = sample_training_scenarios(512,index,horizon=500,
                sampling='coverage128',device='cpu',sampling_report=expected_report)
            exact(seeds,expected_seeds)
            exact(report,expected_report)
            hashes={}
            for field in fields(actual):
                a,b=getattr(actual,field.name),getattr(expected,field.name)
                exact(a,b,field.name)
                hashes[field.name]={'shape':list(a.shape),'dtype':str(a.dtype),
                    'sha256':hashlib.sha256(a.contiguous().reshape(-1).view(torch.uint8).numpy().tobytes()).hexdigest()}
            results.append({'index':index,'fields':hashes,'seeds':seeds,'report':report,'worker':stats})
            del actual,expected
            print({'index':index,'all_fields_raw_bytes_equal':True},flush=True)
        exact(before,capture_rng())
    finally:
        worker.close()
    assert not Path(f'/proc/{worker.pid}').exists()
    atomic_json(Path('reports/cpu_prefetch_20261019/cpu_batch_comparison.json'),
                {'passed':True,'scenes':2048,'horizon':500,'all_fields_raw_bytes_equal':True,
                 'main_rng_exact':True,'worker_closed':True,'results':results})


if __name__=='__main__':main()
