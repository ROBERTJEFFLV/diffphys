"""Exactly C100, P100, P50 + fresh-process resume50; includes complete process wall."""
from pathlib import Path
import json
import shutil
import subprocess
import time

ROOT=Path.cwd()
OUT=ROOT/'reports/cpu_prefetch_20261019'
PYTHON='/tmp/diffphys-cuda-venv/bin/python'
assert json.loads((OUT/'cpu_batch_comparison.json').read_text())['passed']
assert not (OUT/'runs').exists(), 'choose a fresh report directory'
jobs=[('C100','C','C',False,None),('P100','P','P',False,None),
      ('P50','P','P_split',False,50),('P_resume50','P','P_split',True,None)]
results=[]
start=time.perf_counter()
for label,scheme,folder,resume,stop_after in jobs:
    work=OUT/'runs'/folder
    command=[PYTHON,'tools/train_compiled_candidate.py','--config','configs/compiled_prefetch_acceptance.json',
             '--scheme',scheme,'--work-dir',str(work)]
    command+=['--resume',str(work/'latest.pt')] if resume else ['--donor','best.pt']
    if stop_after is not None:command+=['--stop-after',str(stop_after)]
    (OUT/'progress.json').write_text(json.dumps({'active':label,'completed':results},indent=2)+'\n')
    tick=time.perf_counter()
    with (OUT/(label+'.log')).open('w') as log:
        process=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    result={'label':label,'command':command,'returncode':process.returncode,
            'process_wall_seconds':time.perf_counter()-tick}
    results.append(result)
    (OUT/'processes.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    if process.returncode:
        (OUT/'progress.json').write_text(json.dumps({'failed':label,'completed':results},indent=2)+'\n')
        raise SystemExit(process.returncode)
    if label=='P50':shutil.copyfile(work/'latest.pt',OUT/'P_split_50.pt')
(OUT/'progress.json').write_text(json.dumps({'active':None,'completed':results,
                                          'total_wall_seconds':time.perf_counter()-start},indent=2)+'\n')
