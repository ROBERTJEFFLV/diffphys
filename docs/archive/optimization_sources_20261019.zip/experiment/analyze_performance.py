"""Actual C/P totals: overlapping worker and main durations are never summed."""
from pathlib import Path
from collections import Counter,defaultdict
import json
import statistics

ROOT=Path('reports/cpu_prefetch_20261019')
def quantile(values,fraction):
    values=sorted(values);point=(len(values)-1)*fraction;low=int(point);high=min(low+1,len(values)-1)
    return values[low]+(point-low)*(values[high]-values[low])

def stats(values):
    return {'median':statistics.median(values),'p90':quantile(values,.9),
            'p99':quantile(values,.99),'max':max(values),'sum':sum(values),
            'stdev':statistics.stdev(values) if len(values)>1 else 0.}

processes=json.loads((ROOT/'processes.json').read_text())
cases={};all_rows={}
for name,labels in [('C',['C100']),('P',['P100']),('P_split',['P50','P_resume50'])]:
    folder=ROOT/'runs'/name
    rows=[json.loads(x) for x in (folder/'timing.jsonl').read_text().splitlines()]
    all_rows[name]=rows
    segments=[json.loads(p.read_text()) for p in sorted(folder.glob('segment_*.json'))]
    assert len(rows)==100
    result={'timed_updates':len(rows),
            'training_seconds_including_worker_start_close_final_io_gc':sum(s['training_seconds_including_final_io_gc'] for s in segments),
            'full_process_wall_seconds':sum(p['process_wall_seconds'] for p in processes if p['label'] in labels),
            'frozen_compiler_startup_seconds':sum(s['startup_seconds'] for s in segments),
            'worker_close_seconds':sum(s['cleanup'].get('worker_close_seconds',0.) for s in segments),
            'segments':segments}
    for key in [key for key in rows[0] if key.endswith('_seconds')]:
        result[key]=stats([r[key] for r in rows])
    firsts={s['start_update']+1 for s in segments}
    result['first_batch_wait_seconds']={str(r['update']):r['batch_wait_seconds'] for r in rows if r['update'] in firsts}
    result['batch_wait_after_first_per_segment']=stats([r['batch_wait_seconds'] for r in rows if r['update'] not in firsts])
    for key in ['cuda_allocated_bytes','cuda_reserved_bytes','cuda_peak_bytes','rss_bytes',
                'combined_rss_bytes','combined_pss_bytes','worker_rss_bytes','worker_pss_bytes']:
        if key not in rows[0]:continue
        values=[r[key] for r in rows]
        result[key]={'first':values[0],'last':values[-1],'min':min(values),'max':max(values),
                     'ten_update_block_medians':[statistics.median(values[i:i+10]) for i in range(0,100,10)],
                     'last20_minus_first20_median':statistics.median(values[-20:])-statistics.median(values[:20])}
    result['new_graphs_during_training']=sum(r['compiler_after'].get('unique_graphs',0)-r['compiler_before'].get('unique_graphs',0) for r in rows)
    events=[]
    for line in (folder/'gc.jsonl').read_text().splitlines():events.extend(json.loads(line)['events'])
    counts=Counter();durations=defaultdict(float)
    for event in events:
        key=event['stage']+'/gen'+str(event['generation']);counts[key]+=1;durations[key]+=event['duration_ms']
    result['gc_counts']=dict(counts);result['gc_milliseconds']=dict(durations)
    cases[name]=result
c,p=cases['C'],cases['P']
block_reductions=[]
for start in range(0,100,10):
    times={name:sum(r['cycle_seconds'] for r in all_rows[name][start:start+10]) for name in ['C','P']}
    block_reductions.append({'updates':[start+1,start+10],**times,'elapsed_reduction':1-times['P']/times['C']})
result={'cases':cases,
        'C_to_P_training_total_reduction':1-p['training_seconds_including_worker_start_close_final_io_gc']/c['training_seconds_including_worker_start_close_final_io_gc'],
        'C_to_P_full_process_wall_reduction':1-p['full_process_wall_seconds']/c['full_process_wall_seconds'],
        'matched_ten_update_blocks':block_reductions,
        'wait_seconds_removed_including_first':c['batch_wait_seconds']['sum']-p['batch_wait_seconds']['sum'],
        'scope':'300 actual consecutive updates, separate process launches; no state reset per update. Total includes worker startup, communication, first wait, unchanged upload, normal audit/checkpoints, running-task shutdown and final cleanup. Worker generation and main durations overlap and cannot be added. RSS sums double-count shared pages; combined PSS is also recorded. Process wall additionally includes imports and frozen compiler warmup. No profiling/verification competes with measured training.'}
(ROOT/'performance_summary.json').write_text(json.dumps(result,indent=2)+'\n')
for name,value in cases.items():
    print(name,'train',value['training_seconds_including_worker_start_close_final_io_gc'],
          'process',value['full_process_wall_seconds'],'cycle',value['cycle_seconds'],
          'wait',value['batch_wait_seconds'],'close',value['worker_close_seconds'],
          'graphs',value['new_graphs_during_training'])
print('training reduction',result['C_to_P_training_total_reduction'],
      'full process reduction',result['C_to_P_full_process_wall_reduction'])
