"""Finalize source-bound 300-update prefetch evidence, preserving original donor."""
from __future__ import annotations
import copy
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys
import zipfile

import torch

ROOT=Path.cwd();sys.path.insert(0,str(ROOT))
from diffphys.response_training import SOURCE_FILES,source_hash
from tools.verify_compiled_continuity import exact

OUT=ROOT/'reports/cpu_prefetch_20261019'
def digest(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

states=json.loads((OUT/'state_chain_comparison.json').read_text())
keys=json.loads((OUT/'key_h500_comparison.json').read_text())
cpu=json.loads((OUT/'cpu_batch_comparison.json').read_text())
perf=json.loads((OUT/'performance_summary.json').read_text())
progress=json.loads((OUT/'progress.json').read_text())
assert len(progress['completed'])==4 and all(p['returncode']==0 for p in progress['completed'])
assert states['passed'] and states['total_actual_updates']==300
assert keys['passed'] and sorted(map(int,keys['updates']))==[1,50,51,100]
assert all(r['raw_bytes_equal'] for r in keys['updates'].values())
assert cpu['passed'] and [r['index'] for r in cpu['results']]==[0,1,49,50,99]
assert '530 passed, 24 skipped' in (OUT/'pytest_cpu.log').read_text()
assert '45 passed' in (OUT/'pytest_cuda.log').read_text()
final={name:torch.load(OUT/'runs'/name/'latest.pt',map_location='cpu',weights_only=True)
       for name in ['C','P','P_split']}
exact(final['P']['binding'],final['P_split']['binding'])
expected=copy.deepcopy(final['P']['binding']);expected['config']['scheme']='C'
exact(expected,final['C']['binding'])
previous=json.loads((ROOT/'reports/continuous_compiled_20261019/evidence_manifest.json').read_text())
assert source_hash()==previous['production_source_sha256']==final['C']['binding']['production_source_sha256']
assert digest(ROOT/'best.pt')==previous['donor_sha256']==final['C']['binding']['initialization']['donor_sha256']
assert (ROOT/'tests/core_contract.json').read_bytes()==subprocess.check_output(['git','show','HEAD:tests/core_contract.json'])
for name,expected in final['P']['binding']['experimental_sources'].items():assert digest(ROOT/name)==expected,name
for name in ['P','P_split']:
    rows=[json.loads(x) for x in (OUT/'runs'/name/'timing.jsonl').read_text().splitlines()]
    assert len({r['worker_pid'] for r in rows})==(2 if name=='P_split' else 1)
    assert all(not r['worker_cuda_initialized'] and r['worker_threads']==1 for r in rows)
    assert not Path(f'/proc/{rows[-1]["worker_pid"]}').exists()
source_paths=set(SOURCE_FILES)
for folder in ['diffphys','tools','tests','configs','docs']:
    source_paths.update(str(p.relative_to(ROOT)) for p in (ROOT/folder).rglob('*') if p.is_file()
                        and p.suffix in {'.py','.md','.json','.args'} and '__pycache__' not in p.parts)
source_paths.update(['README.md','AGENTS.md','THIRD_PARTY_NOTICES.md'])
source_paths.update(str(p.relative_to(ROOT)) for p in ROOT.glob('LICENSE*') if p.is_file())
with zipfile.ZipFile(OUT/'source_snapshot.zip','w',zipfile.ZIP_DEFLATED) as archive:
    for name in sorted(source_paths):archive.write(ROOT/name,name)
    for p in sorted(OUT.glob('*.py')):archive.write(p,'experiment/'+p.name)
artifacts={str(p.relative_to(OUT)):{'sha256':digest(p),'bytes':p.stat().st_size}
           for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='evidence_manifest.json'}
manifest={'budget':{'C':100,'P':100,'P_split':100,'total_gpu_optimizer_updates':300},
          'all_actor_adam_main_rng_sampling_chains_raw_byte_equal':True,
          'key_h500_raw_group_gradients_and_trajectories_raw_byte_equal':True,
          'cpu_all_fields_tapes_order_reports_raw_byte_equal':True,
          'resume_checkpoint_50_sha256':digest(OUT/'P_split_50.pt'),
          'donor_sha256':digest(ROOT/'best.pt'),'donor_unchanged':True,
          'production_source_sha256':source_hash(),'production_unchanged':True,'protected_contract_unchanged':True,
          'source_hashes':{name:digest(ROOT/name) for name in sorted(source_paths)},'artifacts':artifacts,
          'runtime':{'python':sys.version,'torch':str(torch.__version__),'cuda':torch.version.cuda,
                     'cudnn':torch.backends.cudnn.version(),'platform':platform.platform(),
                     'packages':{name:importlib.metadata.version(name) for name in ['numpy','pytest','triton']},
                     'gpu':subprocess.check_output(['nvidia-smi','--query-gpu=name,driver_version,memory.total','--format=csv,noheader'],text=True).strip()},
          'scope':'One C100/P100 process pair plus P50+50 independent-process resume. All 300 actual updates checked; offline replays call no Adam. Main/worker memory observed for 100 updates, not indefinite. No production promotion or learned-quality/deployment validation. Same hardware/software/config only.'}
(OUT/'evidence_manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'verified':True,'updates':300,'sources':len(source_paths),'artifacts':len(artifacts)}))
