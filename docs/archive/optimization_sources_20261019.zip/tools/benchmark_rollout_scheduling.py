#!/usr/bin/env python3
"""Bounded complete updates and H500 schedule equivalence; no production switch."""
from __future__ import annotations

import argparse
import copy
from dataclasses import fields
import hashlib
import json
from pathlib import Path
import statistics
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch

from diffphys.env_raptor import IMMUTABLE_TAPES, RaptorSimulator, rotation_backend_contract
from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
from diffphys.experimental.masked_rollout import collect_masked_rollout
from diffphys.experimental.strict_inductor import compiler_contract
from diffphys.experimental.training_benchmark import complete_update
from diffphys.response_adjoints import collect_rollout
from diffphys.response_audit import AuditConfig, UpdateAudit
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ARCHITECTURE, ResponseMotorPolicy, ResponsePolicyConfig
from diffphys.response_task import PHYSICAL_DYNAMIC, TaskLossConfig
from diffphys.response_training import (SOURCE_FILES, atomic_json, atomic_torch, capture_rng,
                                       file_hash, migrate_named_adam, model_hash, restore_rng,
                                       source_hash)
from tools.diagnose_rk4_compile import compare_tensor, state_hash

STATE_FIELDS = (*PHYSICAL_DYNAMIC, "step_index", "noise_row")
EXPERIMENT_SOURCES = (
    "diffphys/experimental/masked_rollout.py", "diffphys/experimental/training_benchmark.py",
    "diffphys/experimental/compiled_physics.py", "diffphys/experimental/strict_inductor.py",
    "tools/benchmark_rollout_scheduling.py",
)


def snapshot(state):
    return {name: getattr(state, name).detach().cpu().clone() for name in STATE_FIELDS}


class CaseCapture:
    """Warmup-only snapshots; no recording or host copies in timed rollouts."""
    def __init__(self, policy, simulator, schedule):
        self.policy, self.simulator, self.schedule = policy, simulator, schedule
        self.inputs, self.outputs, self.memories, self.chunks = [], [], [], []
        self.handle = None

    def actor_hook(self, module, inputs, output):
        self.memories.append((inputs[1].memory.detach().cpu().clone(),
                              output.next_state.memory.detach().cpu().clone()))

    def collector(self, *args, **kwargs):
        if self.schedule == "dynamic":
            from diffphys import response_adjoints as owner
            original = owner.rollout
            collector = collect_rollout
            target = "diffphys.response_adjoints.rollout"
        else:
            from diffphys.experimental import masked_rollout as owner
            original = owner.masked_rollout
            collector = collect_masked_rollout
            target = "diffphys.experimental.masked_rollout.masked_rollout"

        def observe(*a, **kw):
            trace = original(*a, **kw)
            tensors = {f.name: getattr(trace, f.name).detach().cpu().clone()
                       for f in fields(trace) if torch.is_tensor(getattr(trace, f.name))}
            self.chunks.append((tensors, snapshot(trace.end.physical),
                                trace.end.policy.memory.detach().cpu().clone()))
            assert all(getattr(trace.end.physical, name) is getattr(trace.initial, name)
                       for name in IMMUTABLE_TAPES)
            return trace

        with patch(target, observe):
            return collector(*args, **kwargs)

    def __enter__(self):
        self.handle = self.policy.register_forward_hook(self.actor_hook)
        capture = self

        class RecordedSimulator(RaptorSimulator):
            def __init__(self):
                super().__init__(capture.simulator.params)

            def step(self, state, action):
                capture.inputs.append(snapshot(state))
                result = capture.simulator.step(state, action)
                capture.outputs.append(snapshot(result))
                return result

        return RecordedSimulator()

    def __exit__(self, *exc):
        self.handle.remove()


class Comparison:
    def __init__(self):
        self.fields = {}

    def add(self, name, reference, actual, step=None, *, derivative=False):
        check = compare_tensor(reference, actual, rtol=1e-5 if derivative else 1e-6, atol=1e-6)
        field = self.fields.setdefault(name, {"close": True, "bitwise_equal": True,
                                             "max_abs": 0., "max_scaled_error": 0.,
                                             "first_difference": None, "first_failure": None,
                                             "error_squared": 0., "reference_squared": 0.})
        field["close"] &= check["close"]
        field["bitwise_equal"] &= check["bitwise_equal"]
        if not check["bitwise_equal"] and field["first_difference"] is None:
            field["first_difference"] = step
        if not check["close"] and field["first_failure"] is None:
            field["first_failure"] = {"step": step, **check}
        if "max_abs" in check:
            field["max_abs"] = max(field["max_abs"], check["max_abs"])
            field["max_scaled_error"] = max(field["max_scaled_error"], check["max_scaled_error"])
            field["error_squared"] += float((actual.double()-reference.double()).square().sum())
            field["reference_squared"] += float(reference.double().square().sum())

    def report(self):
        values = {}
        for name, field in self.fields.items():
            values[name] = {k: v for k, v in field.items() if k not in ("error_squared", "reference_squared")}
            values[name]["relative_l2"] = (field["error_squared"] / max(field["reference_squared"], 1e-30))**.5
        return {"passed": all(v["close"] for v in values.values()),
                "bitwise_equal": all(v["bitwise_equal"] for v in values.values()), "fields": values}


def values_after_update(policy, optimizer, result):
    record = result["record"]
    values = {"costs": record.costs.detach().cpu().clone(),
              "raw_group_gradients": record.probe.rows.detach().cpu().clone(),
              "group_norms_and_multipliers": result["backward"]["group_gradient"]["values"].detach().cpu().clone(),
              "gradient_entering_adam": torch.cat([p.grad.detach().flatten().cpu() for p in policy.parameters()]),
              "pre_global_clip_norm": torch.tensor([result["row"]["raw_gradient_norm"]], dtype=torch.float64),
              "actor_after": torch.cat([p.detach().flatten().cpu() for p in policy.parameters()])}
    for key in ("exp_avg", "exp_avg_sq", "step"):
        values["adam_"+key] = torch.cat([optimizer.state[p][key].detach().flatten().cpu() for p in policy.parameters()])
    return values


def compare_captures(reference, actual, initial, ref_values, values):
    comparison = Comparison()
    for name in ref_values:
        comparison.add("update/"+name, ref_values[name], values[name], derivative=name != "costs")
    assert len(reference.chunks) == len(actual.chunks)
    for chunk, ((a, state_a, memory_a), (b, state_b, memory_b)) in enumerate(zip(reference.chunks, actual.chunks)):
        for name in a:
            for step in range(a[name].shape[0]):
                comparison.add("trajectory/"+name, a[name][step], b[name][step], chunk*50+step+1)
        for name in STATE_FIELDS:
            comparison.add("chunk_end/"+name, state_a[name], state_b[name], (chunk+1)*50)
        comparison.add("chunk_end/memory", memory_a, memory_b, (chunk+1)*50)
    valid = torch.cat([chunk[0]["valid"] for chunk in reference.chunks])
    cache = {name: value.clone() for name, value in initial.items()}
    memory = torch.zeros(len(initial["position"]), reference.policy.config.memory_dim,
                         dtype=initial["position"].dtype)
    cursor_a = cursor_b = 0
    for step in range(len(valid)):
        ids = valid[step].nonzero(as_tuple=True)[0]
        active_a = len(ids) > 0
        active_b = actual.schedule == "mask" or active_a
        if active_b:
            incoming = actual.inputs[cursor_b]
            incoming_ids = incoming["noise_row"].long()
            for name in STATE_FIELDS:
                comparison.add("step_input/"+name, cache[name].index_select(0, incoming_ids), incoming[name], step+1)
            comparison.add("step_input/memory", memory.index_select(0, incoming_ids), actual.memories[cursor_b][0], step+1)
        if active_a:
            a = reference.outputs[cursor_a]
            ref_ids = a["noise_row"].long()
            assert torch.equal(ref_ids, ids)
            if actual.schedule == "mask":
                selected = ids
            else:
                selected = torch.arange(len(ids))
            b = actual.outputs[cursor_b]
            for name in STATE_FIELDS:
                comparison.add("step_output/"+name, a[name], b[name].index_select(0, selected), step+1)
                cache[name].index_copy_(0, ids, a[name])
            comparison.add("step_output/memory", reference.memories[cursor_a][1],
                           actual.memories[cursor_b][1].index_select(0, selected), step+1)
            memory.index_copy_(0, ids, reference.memories[cursor_a][1])
            cursor_a += 1
        if active_b:
            cursor_b += 1
    assert cursor_a == len(reference.inputs) and cursor_b == len(actual.inputs)
    return comparison.report()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, default=Path("best.pt"))
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--scenes", type=int, default=2048)
    parser.add_argument("--horizon", type=int, default=500)
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--measure-rejected", action="store_true",
                        help="time finite but numerically rejected experiments; never label these qualified speedups")
    args = parser.parse_args(argv)
    if args.scenes < 128 or args.scenes % 128 or args.horizon < 1 or args.repeats < 1:
        parser.error("positive horizon/repeats and total scenes divisible by 128 required")
    if args.output.exists() and any(args.output.iterdir()):
        parser.error("use a new experiment output directory")
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(1)
    torch.manual_seed(7)
    if args.device == "cuda":
        if not torch.cuda.is_available():
            parser.error("CUDA unavailable")
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    if saved["architecture"] != ARCHITECTURE:
        raise ValueError("requires original native B checkpoint")
    base = ResponseMotorPolicy(ResponsePolicyConfig(**saved["policy_config"]))
    base.load_state_dict(saved["model"])
    assert model_hash(base) == saved["model_sha256"]
    base = base.to(args.device)
    rng = capture_rng()
    checkpoint_sha = file_hash(args.checkpoint)
    loss = TaskLossConfig(.01, .01, 25.)
    groups = GroupBalanceConfig(max_groups=128, min_scenarios=args.scenes//128, layout="coverage128")
    cases = [("rotation_dynamic", RaptorSimulator(rotation_backend="compile"), "dynamic"),
             ("compiled_dynamic", CompiledRaptorSimulator(), "dynamic"),
             ("compiled_mask", CompiledRaptorSimulator(), "mask")]
    actors, optimizers, audits, warm_values, captures, report = {}, {}, {}, {}, {}, {}
    sources = list(SOURCE_FILES) + list(EXPERIMENT_SOURCES)
    for name, simulator, schedule in cases:
        actor = copy.deepcopy(base)
        optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
        actors[name], optimizers[name] = actor, optimizer
        audits[name] = UpdateAudit(args.output/name, AuditConfig(), evaluation_interval=50,
                                  binding={"experiment": "fixed-checkpoint-complete-update", "checkpoint_sha256": checkpoint_sha,
                                           "production_source_sha256": source_hash(), "schedule": schedule,
                                           "physics": compiler_contract() if name.startswith("compiled") else rotation_backend_contract("compile")},
                                  source_root=ROOT, source_files=sources,
                                  torch_writer=atomic_torch, json_writer=atomic_json)
        actor.load_state_dict(saved["model"])
        migrate_named_adam(optimizer, actor, saved["optimizer"], saved["optimizer_parameter_names"])
        restore_rng(rng)
        capture = CaseCapture(actor, simulator, schedule)
        with capture as recorder:
            result = complete_update(actor, optimizer, recorder, collector=capture.collector,
                                     scenes=args.scenes, horizon=args.horizon, loss=loss, groups=groups,
                                     audit=audits[name], progress={"updates": 0},
                                     history=args.output/name/"measurements.jsonl", extra_row={"warmup": True})
        warm_values[name] = values_after_update(actor, optimizer, result)
        captures[name] = capture
        report[name] = {"warmup": result["timings"], "physical_transitions": result["record"].metrics["physical_transitions"],
                        "scheduled_physics_rows": sum(len(s["position"]) for s in capture.inputs),
                        "initial_sha256": state_hash(result["initial"]), "samples": []}
        if name == "rotation_dynamic":
            initial = snapshot(result["initial"])
            report[name]["numerics"] = {"passed": True, "bitwise_equal": True, "reference": True}
        else:
            report[name]["numerics"] = compare_captures(captures["rotation_dynamic"], capture, initial,
                                                        warm_values["rotation_dynamic"], warm_values[name])
        atomic_json(args.output/"progress.json", report)
        print(json.dumps({"phase": "warmup_and_qualification", "case": name,
                          "passed": report[name]["numerics"]["passed"],
                          "bitwise_equal": report[name]["numerics"]["bitwise_equal"]}), flush=True)
        del result
    torch.save(warm_values, args.output/"warmup_update_values.pt")
    report["compiled_mask"]["versus_compiled_dynamic"] = compare_captures(
        captures["compiled_dynamic"], captures["compiled_mask"], initial,
        warm_values["compiled_dynamic"], warm_values["compiled_mask"])
    del captures, capture, recorder
    for trial in range(args.repeats):
        order = cases[trial % len(cases):] + cases[:trial % len(cases)]
        for name, simulator, schedule in order:
            if not report[name]["numerics"]["passed"] and not args.measure_rejected:
                continue
            actor, optimizer = actors[name], optimizers[name]
            actor.load_state_dict(saved["model"])
            migrate_named_adam(optimizer, actor, saved["optimizer"], saved["optimizer_parameter_names"])
            restore_rng(rng)
            if args.device == "cuda":
                torch.cuda.reset_peak_memory_stats()
            result = complete_update(actor, optimizer, simulator,
                                     collector=collect_rollout if schedule == "dynamic" else collect_masked_rollout,
                                     scenes=args.scenes, horizon=args.horizon, loss=loss, groups=groups,
                                     audit=audits[name], progress={"updates": 0},
                                     history=args.output/name/"measurements.jsonl",
                                     extra_row={"warmup": False, "trial": trial})
            actual = values_after_update(actor, optimizer, result)
            repeat_checks = {key: compare_tensor(warm_values[name][key], value,
                                                rtol=1e-6 if key == "costs" else 1e-5, atol=1e-6)
                             for key, value in actual.items()}
            row = {**result["timings"], "trial": trial,
                   "physical_transitions": result["record"].metrics["physical_transitions"],
                   "peak_allocated_bytes": torch.cuda.max_memory_allocated() if args.device == "cuda" else None,
                   "initial_sha256": state_hash(result["initial"]),
                   "same_case_numerics": repeat_checks}
            assert row["initial_sha256"] == report[name]["initial_sha256"]
            report[name]["samples"].append(row)
            atomic_json(args.output/"progress.json", report)
            print(json.dumps({"phase": "timed_update", "case": name, "trial": trial,
                              "seconds": row["complete_update_seconds"]}), flush=True)
            del result, actual
    for name, _, _ in cases:
        rows = report[name]["samples"]
        report[name]["medians"] = {key: statistics.median(row[key] for row in rows)
                                   for key in rows[0] if key.endswith("seconds")} if rows else {}
    assert file_hash(args.checkpoint) == checkpoint_sha
    atomic_json(args.output/"report.json", {"cases": report, "torch": str(torch.__version__),
                "device": args.device, "scenes": args.scenes, "horizon": args.horizon,
                "checkpoint_sha256": checkpoint_sha, "model_sha256": saved["model_sha256"],
                "source_sha256": source_hash(), "experimental_sources": {s: file_hash(ROOT/s) for s in EXPERIMENT_SOURCES},
                "budget": {"warmup_updates_per_case": 1, "timed_updates_per_case": args.repeats},
                "scope": "Every update restores best.pt weights/named Adam, experiment sampling index 0. Includes backup, sampling, stats, clipping, Adam, finite checks, real audit/history I/O. Periodic checkpoint/EVAL excluded. Rejected results are experimental throughput, not qualified acceleration."})
    return report


if __name__ == "__main__":
    main()
