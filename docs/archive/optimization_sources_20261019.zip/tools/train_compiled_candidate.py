#!/usr/bin/env python3
"""Bounded independent continuous A/C/P acceptance; never rewrites donor bindings."""
from __future__ import annotations
import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from diffphys.experimental.continuous_training import CandidateConfig, run


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path('configs/compiled_candidate_acceptance.json'))
    parser.add_argument('--scheme',choices=['A','C','P'])
    parser.add_argument('--work-dir',type=Path,required=True)
    initialize=parser.add_mutually_exclusive_group(required=True)
    initialize.add_argument('--donor',type=Path,help='explicit model + named Adam experiment transplant; not resume')
    initialize.add_argument('--resume',type=Path,help='strict new candidate checkpoint only')
    parser.add_argument('--stop-after',type=int)
    parser.add_argument('--device',choices=['cpu','cuda'])
    parser.add_argument('--scenes',type=int)
    parser.add_argument('--horizon',type=int)
    parser.add_argument('--updates',type=int)
    parser.add_argument('--bool-index-fill',action='store_true',default=None)
    args=parser.parse_args()
    values=json.loads(args.config.read_text())
    for name in asdict(CandidateConfig()):
        value=getattr(args,name,None)
        if value is not None:values[name]=value
    config=CandidateConfig(**values)
    result=run(config,args.work_dir,donor=args.donor,resume=args.resume,stop_after=args.stop_after)
    print(json.dumps({k:v for k,v in result.items() if k!='binding'}),flush=True)


if __name__=='__main__':main()
