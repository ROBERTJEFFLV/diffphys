#!/usr/bin/env python3
"""NVTX/CUPTI scheduling capture and Nsight SQLite interval-union analysis."""
from __future__ import annotations

import argparse
import ast
from bisect import bisect_right
from collections import Counter
from contextlib import ExitStack
import gc
import inspect
from pathlib import Path
import sqlite3
import sys
import textwrap
import time
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch

from diffphys.response_training import atomic_json


def merge_intervals(intervals):
    result = []
    for start, end in sorted(intervals):
        if end <= start:
            continue
        if not result or start > result[-1][1]:
            result.append((start, end))
        else:
            result[-1] = (result[-1][0], max(end, result[-1][1]))
    return result


def inside(timestamp, windows):
    index = bisect_right(windows, (timestamp, float("inf"))) - 1
    return index >= 0 and timestamp < windows[index][1]


def activity_window(start, end, activities, launches, gc_intervals=()):
    work = [(max(a, start), min(b, end), cid, kind)
            for a, b, cid, kind in activities if b > start and a < end]
    occupied = merge_intervals((a, b) for a, b, _, _ in work)
    kernels = merge_intervals((a, b) for a, b, _, kind in work if kind == "kernel")
    gaps, cursor = [], start
    for a, b in occupied:
        if a > cursor:
            gaps.append((cursor, a))
        cursor = max(cursor, b)
    if cursor < end:
        gaps.append((cursor, end))
    starts = {}
    for a, _, cid, _ in work:
        if cid in launches:
            starts[a] = min(starts.get(a, launches[cid][0]), launches[cid][0])
    late = sum(max(0, min(b, starts[b])-a) for a, b in gaps if b in starts)
    durations = sorted(b-a for a, b in gaps)

    def percentile(fraction):
        if not durations:
            return 0.
        position = (len(durations)-1) * fraction
        low = int(position)
        high = min(low+1, len(durations)-1)
        return (durations[low] + (position-low)*(durations[high]-durations[low])) / 1000

    busy = sum(b-a for a, b in occupied)
    gc_ranges = merge_intervals(gc_intervals)
    gap_index = gc_index = gc_overlap = 0
    while gap_index < len(gaps) and gc_index < len(gc_ranges):
        a, b = gaps[gap_index]
        c, d = gc_ranges[gc_index]
        gc_overlap += max(0, min(b, d)-max(a, c))
        if b <= d:
            gap_index += 1
        else:
            gc_index += 1
    return {"wall_ms": (end-start)/1e6,
            "all_gpu_activity_ms": busy/1e6,
            "kernel_active_ms": sum(b-a for a, b in kernels)/1e6,
            "no_traced_activity_ms": ((end-start)-busy)/1e6,
            "no_traced_activity_fraction": 1-busy/max(end-start, 1),
            "host_late_submission_ms": late/1e6,
            "gc_overlap_no_gpu_work_ms": gc_overlap/1e6,
            "activity_count": len(work), "gap_count": len(gaps),
            "gap_p50_us": percentile(.5), "gap_p95_us": percentile(.95),
            "gap_max_us": max(durations, default=0)/1000,
            "gaps_gt_10us": sum(x > 10_000 for x in durations),
            "gaps_gt_100us": sum(x > 100_000 for x in durations),
            "gaps_gt_1ms": sum(x > 1_000_000 for x in durations)}


def analyze(path: Path):
    database = sqlite3.connect(path)
    strings = dict(database.execute("SELECT id,value FROM StringIds"))
    tables = {row[0] for row in database.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    ranges = [(a, b, text or strings.get(text_id), tid) for a, b, text, text_id, tid in
              database.execute("SELECT start,end,text,textId,globalTid FROM NVTX_EVENTS WHERE end IS NOT NULL")]
    apis = [(a, b, strings[name], cid, tid) for a, b, name, cid, tid in
            database.execute("SELECT start,end,nameId,correlationId,globalTid FROM CUPTI_ACTIVITY_KIND_RUNTIME")]
    launches = {cid: (a, b) for a, b, _, cid, _ in apis}
    activities = []
    for suffix, kind in (("KERNEL", "kernel"), ("MEMCPY", "memcpy"), ("MEMSET", "memset")):
        table = "CUPTI_ACTIVITY_KIND_" + suffix
        if table in tables:
            activities.extend((a, b, cid, kind) for a, b, cid in
                              database.execute(f"SELECT start,end,correlationId FROM {table}"))
    activities.sort()
    steps = sorted((a, b) for a, b, name, _ in ranges if name == "schedule/step")
    gc_ranges = [(a, b) for a, b, name, _ in ranges if name and name.startswith("schedule/python_gc_gen")]
    result = {"sqlite": str(path), "steps": len(steps), "phases": {}}
    for phase in ("forward", "backward"):
        windows = [(a, b) for a, b, name, _ in ranges if name == "schedule/"+phase]
        if len(windows) != 1:
            raise ValueError("expected exactly one captured "+phase+" phase")
        start, end = windows[0]
        selected = [(a, b, name, cid, tid) for a, b, name, cid, tid in apis if start <= a < end]
        sync = [(a, b) for a, b, name, _, _ in selected if "Synchronize" in name]
        launch = [(a, b) for a, b, name, _, _ in selected if "Launch" in name]
        metrics = activity_window(start, end, activities, launches, gc_ranges)
        metrics.update(sync_api_count=len(sync), sync_api_ms=sum(b-a for a, b in sync)/1e6,
                       sync_api_wall_union_ms=sum(b-a for a, b in merge_intervals(sync))/1e6,
                       launch_api_count=len(launch), launch_api_ms=sum(b-a for a, b in launch)/1e6)
        result["phases"][phase] = metrics
        result["phases"][phase]["python_gc_ms"] = sum(
            max(0, min(b, end)-max(a, start)) for a, b, name, _ in ranges
            if name and name.startswith("schedule/python_gc_gen"))/1e6
    result["nonzero"] = {}
    for label, predicate in (("all", lambda a: True), ("inside_steps", lambda a: inside(a, steps))):
        scopes = [(a, b, tid) for a, b, name, tid in ranges
                  if name == "schedule/nonzero" and predicate(a)]
        sync = [(a, b) for a, b, name, _, tid in apis if "Synchronize" in name
                and any(tid == parent_tid and left <= a and b <= right for left, right, parent_tid in scopes)]
        result["nonzero"][label] = {"count": len(scopes), "inclusive_cpu_ms": sum(b-a for a, b, _ in scopes)/1e6,
                                    "sync_api_count": len(sync), "sync_api_ms": sum(b-a for a, b in sync)/1e6}
    step_apis = [(a, b, name) for a, b, name, _, _ in apis if inside(a, steps)]
    result["inside_steps"] = {"cpu_range_ms": sum(b-a for a, b in steps)/1e6,
                              "sync_api_count": sum("Synchronize" in name for _, _, name in step_apis),
                              "sync_api_ms": sum(b-a for a, b, name in step_apis if "Synchronize" in name)/1e6,
                              "host_scalar_ranges": dict(Counter(name for a, _, name, _ in ranges
                                                                  if name in ("schedule/__bool__", "schedule/__int__", "schedule/__float__") and inside(a, steps)))}
    chunk_gpu_windows = []
    for a, b, name, _ in ranges:
        if name != "schedule/rollout_chunk":
            continue
        chunk_steps = [(x, y) for x, y in steps if a <= x < b]
        members = [(x, y) for x, y, cid, _ in activities
                   if cid in launches and inside(launches[cid][0], chunk_steps)]
        if members:
            chunk_gpu_windows.append(activity_window(min(x for x, _ in members), max(y for _, y in members), activities, launches, gc_ranges))
    result["step_gpu_chunk_windows"] = chunk_gpu_windows
    result["python_gc"] = [{"generation": int(name[-1]), "duration_ms": (b-a)/1e6,
                             "inside_step": inside(a, steps)}
                            for a, b, name, _ in ranges
                            if name and name.startswith("schedule/python_gc_gen")]
    result["scope"] = ("GPU work is the interval union of this process's kernels/copies/memsets. Gaps are not SM occupancy or whole-device utilization. Host-late time is a conservative gap portion before the next GPU activity's correlated CUDA API starts. Nsight adds overhead; use unprofiled complete-update timings for speed claims. CPU nonzero time includes child waits and must not be added to them.")
    database.close()
    return result


def capture(args):
    from diffphys import response_task
    from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
    from diffphys.experimental import masked_rollout as mask_owner
    from diffphys.response_adjoints import collect_rollout, backward_actor
    from diffphys.response_groups import GroupBalanceConfig
    from diffphys.response_policy import ResponseMotorPolicy, ResponsePolicyConfig
    from diffphys.response_task import TaskLossConfig
    from diffphys.response_training import file_hash, model_hash, sample_training_scenarios

    torch.set_num_threads(1)
    torch.manual_seed(7)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
    policy = ResponseMotorPolicy(ResponsePolicyConfig(**saved["policy_config"])).cuda()
    policy.load_state_dict(saved["model"])
    original_model = model_hash(policy)
    initial, _ = sample_training_scenarios(args.scenes//4, 0, horizon=args.horizon,
                                          sampling="coverage128", device="cuda")
    simulator = CompiledRaptorSimulator()
    loss = TaskLossConfig(.01, .01, 25.)
    groups = GroupBalanceConfig(max_groups=128, min_scenarios=args.scenes//128, layout="coverage128")
    collector = collect_rollout if args.schedule == "dynamic" else mask_owner.collect_masked_rollout
    gc_runs = {}

    def run(label):
        events, starts = [], {}
        stage = "forward"

        def on_gc(phase, info):
            generation = info["generation"]
            if phase == "start":
                starts[generation] = (time.perf_counter_ns(), stage)
                torch.cuda.nvtx.range_push("schedule/python_gc_gen"+str(generation))
            else:
                torch.cuda.nvtx.range_pop()
                begin, parent = starts.pop(generation)
                events.append({"stage": parent, "generation": generation,
                               "duration_ms": (time.perf_counter_ns()-begin)/1e6,
                               "collected": info["collected"]})

        gc.callbacks.append(on_gc)
        try:
            policy.zero_grad(set_to_none=True)
            with torch.cuda.nvtx.range("schedule/forward"):
                record = collector(policy, simulator, initial, loss, horizon=args.horizon,
                                   time_decay=1., group_config=groups)
                torch.cuda.synchronize()
            stage = "backward"
            with torch.cuda.nvtx.range("schedule/backward"):
                backward_actor(policy, simulator, record, loss)
                torch.cuda.synchronize()
            stage = "cleanup"
            transitions = record.metrics["physical_transitions"]
            del record
        finally:
            gc.callbacks.remove(on_gc)
        gc_runs[label] = events
        return transitions

    run("bare_warmup")
    start = time.perf_counter()
    run("bare_timed")
    bare = time.perf_counter()-start
    original = response_task.rollout if args.schedule == "dynamic" else mask_owner.masked_rollout
    tree = ast.parse(textwrap.dedent(inspect.getsource(original)))
    function = tree.body[0]
    function.name = "annotated_rollout"
    for node in function.body:
        if isinstance(node, ast.For) and isinstance(node.target, ast.Name) and node.target.id == "step":
            node.body = [ast.With(items=[ast.withitem(context_expr=ast.Call(
                func=ast.Name(id="_nvtx_range", ctx=ast.Load()), args=[ast.Constant("schedule/step")], keywords=[]),
                optional_vars=None)], body=node.body)]
            break
    else:
        raise AssertionError("original step loop not found")
    namespace = {**original.__globals__, "_nvtx_range": torch.cuda.nvtx.range}
    exec(compile(ast.fix_missing_locations(tree), "<NVTX_only_rollout>", "exec"), namespace)

    def chunk(*a, **kw):
        with torch.cuda.nvtx.range("schedule/rollout_chunk"):
            return namespace["annotated_rollout"](*a, **kw)

    def annotate(method, label):
        def wrapped(self, *a, **kw):
            with torch.cuda.nvtx.range(label):
                return method(self, *a, **kw)
        return wrapped

    target = "diffphys.response_adjoints.rollout" if args.schedule == "dynamic" else "diffphys.experimental.masked_rollout.masked_rollout"
    with ExitStack() as stack:
        stack.enter_context(patch(target, chunk))
        for name in ("nonzero", "__bool__", "__int__", "__float__"):
            stack.enter_context(patch.object(torch.Tensor, name, annotate(getattr(torch.Tensor, name), "schedule/"+name)))
        run("annotated_warmup")
        start = time.perf_counter()
        run("annotated_untraced")
        instrumented = time.perf_counter()-start
        torch.cuda.profiler.start()
        start = time.perf_counter()
        transitions = run("profiled")
        elapsed = time.perf_counter()-start
        torch.cuda.profiler.stop()
    assert model_hash(policy) == original_model
    return {"schedule": args.schedule, "bare_seconds": bare, "instrumented_untraced_seconds": instrumented,
            "profiled_seconds": elapsed, "profiling_wall_ratio": elapsed/bare,
            "physical_transitions": transitions, "torch": str(torch.__version__),
            "checkpoint_sha256": file_hash(args.checkpoint), "model_unchanged": True,
            "python_gc_runs": gc_runs, "gc_enabled": gc.isenabled(),
            "scope": "Frozen H500 forward/backward; no Adam. Only NVTX scopes are inserted into the original step loop. Capture via nsys --capture-range=cudaProfilerApi."}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analyze", type=Path)
    parser.add_argument("--schedule", choices=("dynamic", "mask"), default="dynamic")
    parser.add_argument("--checkpoint", type=Path, default=Path("best.pt"))
    parser.add_argument("--scenes", type=int, default=2048)
    parser.add_argument("--horizon", type=int, default=500)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args(argv)
    result = analyze(args.analyze) if args.analyze else capture(args)
    atomic_json(args.report, result)
    print({"report": str(args.report), **{key: result[key] for key in
           ("schedule", "bare_seconds", "profiled_seconds", "profiling_wall_ratio", "steps")
           if key in result}}, flush=True)


if __name__ == "__main__":
    main()
