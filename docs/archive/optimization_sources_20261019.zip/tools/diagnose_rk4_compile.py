#!/usr/bin/env python3
"""Compare one compiled original RK4 step in an eager rollout, without training.

Records first trajectory divergence, costs, native probe rows, clipping and a
disposable shadow Adam update. Compiler errors propagate. Numerical failures
are written to the report and produce exit status 1. No checkpoint is written.
"""
from __future__ import annotations

import argparse
import copy
from dataclasses import asdict, fields, replace
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch

from diffphys.env_raptor import IMMUTABLE_TAPES, RaptorSimulator, rotation_backend_contract
from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
from diffphys.response_adjoints import collect_rollout, backward_actor
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ARCHITECTURE, ResponseMotorPolicy, ResponsePolicyConfig
from diffphys.response_task import PHYSICAL_DYNAMIC, TaskLossConfig
from diffphys.response_training import (atomic_json, file_hash, model_hash, safe_global_clip,
                                       sample_training_scenarios, source_hash, migrate_named_adam)


def compare_tensor(reference, actual, *, rtol, atol):
    reference, actual = reference.detach().cpu(), actual.detach().cpu()
    if reference.shape != actual.shape or reference.dtype != actual.dtype:
        return {"close": False, "bitwise_equal": False, "reason": "shape or dtype mismatch"}
    if not bool(torch.isfinite(reference).all() & torch.isfinite(actual).all()):
        return {"close": False, "bitwise_equal": False, "reason": "nonfinite tensor"}
    error = (actual.double() - reference.double()).abs()
    return {"close": bool(torch.allclose(actual, reference, rtol=rtol, atol=atol)),
            "bitwise_equal": torch.equal(actual, reference),
            "max_abs": float(error.max()) if error.numel() else 0.,
            "relative_l2": float(error.norm() / reference.double().norm().clamp_min(1e-30)),
            "max_scaled_error": float((error / (atol + rtol * reference.double().abs())).max()) if error.numel() else 0.}


def rounding_options(rounding):
    options = {"triton.cudagraphs": False}
    if rounding in ("division", "division-casts"):
        # The same compiler control was renamed after 2.10. Record the actual key.
        known = torch._inductor.list_options()
        key = ("emulate_divison_rounding" if "emulate_divison_rounding" in known
               else "eager_numerics.division_rounding")
        if key not in known:
            raise RuntimeError("this Inductor version has no supported division-rounding control")
        options[key] = True
    if rounding in ("casts", "division-casts"):
        options["emulate_precision_casts"] = True
    return options


def snapshot(state):
    return {name: getattr(state, name).detach().cpu().clone()
            for name in (*PHYSICAL_DYNAMIC, "step_index", "noise_row")}


def state_hash(state):
    digest = hashlib.sha256()
    for field in fields(state):
        value = getattr(state, field.name).detach().cpu().contiguous()
        digest.update(str((field.name, value.dtype, tuple(value.shape))).encode())
        digest.update(value.numpy().tobytes())
    return digest.hexdigest()


class RecordedSteps(RaptorSimulator):
    def __init__(self, simulator):
        super().__init__(simulator.params)
        self.simulator, self.steps = simulator, []

    def step(self, state, action):
        result = self.simulator.step(state, action)
        self.steps.append(snapshot(result))
        return result


def compare_steps(reference, actual, tolerance):
    first_bitwise, first_tolerance = None, None
    for index, (a, b) in enumerate(zip(reference, actual)):
        for name in a:
            check = compare_tensor(a[name], b[name], **tolerance)
            event = {"step": index + 1, "field": name, **check}
            if first_bitwise is None and not check["bitwise_equal"]:
                first_bitwise = event
            if first_tolerance is None and not check["close"]:
                first_tolerance = event
    same_length = len(reference) == len(actual)
    if not same_length and first_tolerance is None:
        first_tolerance = {"step": min(len(reference), len(actual)) + 1,
                           "field": "step_count", "close": False}
    return {"close": first_tolerance is None and same_length,
            "bitwise_equal": first_bitwise is None and same_length,
            "first_bitwise_difference": first_bitwise,
            "first_outside_tolerance": first_tolerance,
            "eager_steps": len(reference), "candidate_steps": len(actual)}


def one_step(simulator, initial):
    # The same pooled tapes are retained; choose a real pulse transition if present.
    active = initial.pulse_active_tape.nonzero()
    index = int(active[:, 1].min()) if active.numel() else 0
    state = replace(initial, step_index=torch.full_like(initial.step_index, index),
                    **{name: getattr(initial, name).detach().clone().requires_grad_()
                       for name in PHYSICAL_DYNAMIC})
    action = torch.linspace(-1.2, 1.2, initial.motor.numel(), device=initial.motor.device,
                            dtype=initial.motor.dtype).reshape_as(initial.motor).requires_grad_()
    result = simulator.step(state, action)
    inputs = [getattr(state, name) for name in PHYSICAL_DYNAMIC] + [action]
    objective = sum(getattr(result, name).square().sum() for name in PHYSICAL_DYNAMIC)
    gradients = torch.autograd.grad(objective, inputs, allow_unused=True)
    outputs = {field.name: getattr(result, field.name).detach().cpu().clone()
               for field in fields(result) if field.name not in IMMUTABLE_TAPES}
    derivatives = {name: (gradient if gradient is not None else torch.zeros_like(value)).detach().cpu()
                   for name, gradient, value in zip((*PHYSICAL_DYNAMIC, "action"), gradients, inputs)}
    return outputs, derivatives, index


def rollout_result(simulator, policy, initial, loss, groups, horizon, optimizer_checkpoint=None):
    policy = copy.deepcopy(policy)
    recorder = RecordedSteps(simulator)
    start = time.perf_counter()
    record = collect_rollout(policy, recorder, initial, loss, horizon=horizon,
                             time_decay=1., group_config=groups)
    costs = record.costs.detach().cpu().clone()
    report = backward_actor(policy, recorder, record, loss)["group_gradient"]
    result = {"costs": costs, "raw_group_gradients": record.probe.rows.detach().cpu().clone(),
              "group_norms_and_multipliers": report["values"].detach().cpu().clone(),
              "clipped_gradient": torch.cat([p.grad.flatten() for p in policy.parameters()]).detach().cpu()}
    safe_global_clip(list(policy.parameters()), 10.)
    result["global_clipped_gradient"] = torch.cat([p.grad.flatten() for p in policy.parameters()]).detach().cpu()
    optimizer = torch.optim.Adam(policy.parameters(), lr=3e-4)
    if optimizer_checkpoint is not None:
        migrate_named_adam(optimizer, policy, optimizer_checkpoint["optimizer"],
                           optimizer_checkpoint["optimizer_parameter_names"])
    optimizer.step()  # Disposable in-memory comparison; no training/checkpoint output.
    result["shadow_actor"] = torch.cat([p.detach().flatten() for p in policy.parameters()]).cpu()
    for key in ("exp_avg", "exp_avg_sq", "step"):
        result["adam_" + key] = torch.cat([optimizer.state[p][key].flatten().cpu() for p in policy.parameters()])
    metadata = {"physical_transitions": record.metrics["physical_transitions"],
                "steps_executed": len(recorder.steps),
                "shadow_adam_step_after": float(next(iter(optimizer.state.values()))["step"]),
                "seconds_including_compile_and_recording": time.perf_counter() - start}
    return result, recorder.steps, metadata


def benchmark(simulators, policy, initial, loss, groups, horizon, repeats):
    """Warm each backend once, then time unchanged frozen forward/backward only."""
    device = initial.motor.device
    samples = {name: [] for name in simulators}
    copies = {name: copy.deepcopy(policy) for name in simulators}

    def synchronize():
        if device.type == "cuda":
            torch.cuda.synchronize(device)

    for iteration in range(repeats + 1):
        order = list(simulators)
        shift = (iteration // 2) % len(order)
        order = order[shift:] + order[:shift]
        if iteration % 2:
            order.reverse()
        for name in order:
            actor = copies[name]
            actor.zero_grad(set_to_none=True)
            synchronize()
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats(device)
            start = time.perf_counter()
            record = collect_rollout(actor, simulators[name], initial, loss, horizon=horizon,
                                     time_decay=1., group_config=groups)
            synchronize()
            middle = time.perf_counter()
            backward_actor(actor, simulators[name], record, loss)
            synchronize()
            end = time.perf_counter()
            if iteration:
                samples[name].append({"forward_seconds": middle - start,
                                      "backward_seconds": end - middle, "seconds": end - start,
                                      "physical_transitions": record.metrics["physical_transitions"],
                                      "peak_allocated_bytes": torch.cuda.max_memory_allocated(device) if device.type == "cuda" else None})
            del record
    medians = {name: statistics.median(row["seconds"] for row in rows) for name, rows in samples.items()}
    return {"samples": samples, "median_seconds": medians,
            "speedup_vs_eager": {name: medians["eager"] / value for name, value in medians.items()},
            "speedup_vs_rotation": {name: medians["rotation"] / value for name, value in medians.items()} if "rotation" in medians else None,
            "scope": "One warmup excluded; synchronized frozen rollout/backward; no recording, shadow Adam or training. Sampling excluded."}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cuda")
    parser.add_argument("--dtype", choices=("float32", "float64"), default="float32")
    parser.add_argument("--backend", choices=("compiled", "eager", "aot_eager", "inductor", "rotation"), default="compiled",
                        help="compiled preserves native arithmetic boundaries; inductor reproduces the unconstrained compiler")
    parser.add_argument("--require-bitwise", action="store_true",
                        help="require exact trajectory and rollout/gradient/Adam results before timing")
    parser.add_argument("--compare-rotation", action="store_true",
                        help="also gate and time the existing production rotation-only compiler")
    parser.add_argument("--rounding", choices=("default", "division", "casts", "division-casts"), default="default")
    parser.add_argument("--scenes", type=int, default=128)
    parser.add_argument("--sampling", choices=("random", "coverage128"), default="coverage128")
    parser.add_argument("--horizon", type=int, default=16)
    parser.add_argument("--seed", type=int, default=7)
    parser.add_argument("--checkpoint", type=Path)
    parser.add_argument("--timing-repeats", type=int, default=0,
                        help="warm paired timings only after all numerical checks pass")
    parser.add_argument("--epsilon-p", type=float, required=True)
    parser.add_argument("--epsilon-a", type=float, required=True)
    parser.add_argument("--lambda-R", type=float, required=True)
    parser.add_argument("--report", type=Path, required=True)
    args = parser.parse_args(argv)
    args.require_bitwise = args.require_bitwise or args.backend == "compiled"
    if args.scenes < 4 or args.scenes % 4 or args.horizon < 1:
        parser.error("positive horizon and total scenes divisible by four required")
    if args.timing_repeats < 0:
        parser.error("timing-repeats must be nonnegative")
    if args.sampling == "random" and args.scenes < 32:
        parser.error("adaptive groups require at least 32 initial scenes")
    if args.device == "cuda" and not torch.cuda.is_available():
        parser.error("CUDA unavailable; no CPU substitution")
    if args.backend != "inductor" and args.rounding != "default":
        parser.error("rounding options apply only to Inductor")
    if args.compare_rotation and args.backend == "rotation":
        parser.error("rotation reference would duplicate the selected backend")
    if args.checkpoint and args.report.resolve() == args.checkpoint.resolve():
        parser.error("report must not overwrite input checkpoint")
    loss = TaskLossConfig(args.epsilon_p, args.epsilon_a, args.lambda_R)
    options = rotation_backend_contract("compile")["options"] if args.backend == "rotation" else rounding_options(args.rounding)
    if args.backend == "compiled":
        from diffphys.experimental.strict_inductor import compiler_contract
        options = compiler_contract()["options"]
    state_tol = {"rtol": 1e-6, "atol": 1e-6} if args.dtype == "float32" else {"rtol": 3e-9, "atol": 2e-10}
    grad_tol = {"rtol": 1e-5, "atol": 1e-6} if args.dtype == "float32" else state_tol
    torch.set_num_threads(1)
    torch.manual_seed(args.seed)
    if args.device == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    dtype = getattr(torch, args.dtype)
    saved = torch.load(args.checkpoint, map_location="cpu", weights_only=True) if args.checkpoint else None
    if saved is not None and saved.get("architecture") != ARCHITECTURE:
        raise ValueError("requires native hidden-only B weights; no architecture conversion")
    policy = ResponseMotorPolicy(ResponsePolicyConfig(**saved["policy_config"]) if saved else ResponsePolicyConfig())
    if saved is not None:
        policy.load_state_dict(saved["model"], strict=True)
        if model_hash(policy) != saved.get("model_sha256"):
            raise ValueError("checkpoint model digest mismatch")
    policy = policy.to(device=args.device, dtype=dtype)
    before = model_hash(policy)
    initial, seeds = sample_training_scenarios(args.scenes // 4, 0, horizon=args.horizon,
                                               sampling=args.sampling, device=args.device, dtype=dtype)
    input_hash = state_hash(initial)
    groups = (GroupBalanceConfig(max_groups=128, min_scenarios=args.scenes // 128, layout="coverage128")
              if args.sampling == "coverage128" else GroupBalanceConfig())
    reference = RaptorSimulator()
    candidate = (RaptorSimulator(rotation_backend="compile") if args.backend == "rotation" else
                 CompiledRaptorSimulator(backend=args.backend, options=options if args.backend == "inductor" else None))
    a, ag, pulse_index = one_step(reference, initial)
    b, bg, _ = one_step(candidate, initial)
    single = {name: compare_tensor(a[name], b[name], **state_tol) for name in a}
    single_grad = {name: compare_tensor(ag[name], bg[name], **grad_tol) for name in ag}
    print(json.dumps({"phase": "single_step", "passed": all(v["close"] for v in [*single.values(), *single_grad.values()])}), flush=True)
    a, steps_a, meta_a = rollout_result(reference, policy, initial, loss, groups, args.horizon, saved)
    b, steps_b, meta_b = rollout_result(candidate, policy, initial, loss, groups, args.horizon, saved)
    checks = {name: compare_tensor(a[name], b[name], **(state_tol if name == "costs" else grad_tol)) for name in a}
    trajectory = compare_steps(steps_a, steps_b, state_tol)
    zero_drift = trajectory["bitwise_equal"] and all(v["bitwise_equal"] for v in [*single.values(), *single_grad.values(), *checks.values()])
    if model_hash(policy) != before:
        raise RuntimeError("diagnostic changed the input Actor")
    report = {"passed": all(v["close"] for v in [*single.values(), *single_grad.values(), *checks.values(), trajectory]) and (zero_drift or not args.require_bitwise),
              "zero_drift": zero_drift, "require_bitwise": args.require_bitwise,
              "torch_version": str(torch.__version__), "cuda_version": torch.version.cuda,
              "device": args.device, "device_name": torch.cuda.get_device_name() if args.device == "cuda" else "CPU",
              "dtype": args.dtype, "seed": args.seed, "train_seeds": seeds,
              "scenes": args.scenes, "horizon": args.horizon, "sampling": args.sampling,
              "loss": asdict(loss), "time_decay": 1., "gradient_scale": .1,
              "group_config": asdict(groups), "global_clip": 10.,
              "shadow_adam_initialization": "checkpoint named moments" if saved else "fresh",
              "shadow_adam_lr": saved["optimizer"]["param_groups"][0]["lr"] if saved else 3e-4,
              "compiler": {"backend": "inductor" if args.backend in ("compiled", "rotation") else args.backend,
                           "variant": args.backend,
                           "boundary": "quaternion_rotation" if args.backend == "rotation" else "RaptorSimulator.step",
                           "fullgraph": True, "dynamic": True,
                           "options": options if args.backend in ("compiled", "inductor", "rotation") else None,
                           "contract": compiler_contract() if args.backend == "compiled" else None},
              "tolerances": {"state_and_cost": state_tol, "derivatives": grad_tol},
              "model_sha256": before, "checkpoint_sha256": file_hash(args.checkpoint) if args.checkpoint else None,
              "initial_state_and_tapes_sha256": input_hash,
              "source_sha256": source_hash(), "diagnostic_sources": {
                  name: file_hash(ROOT / name) for name in ("tools/diagnose_rk4_compile.py",
                  "diffphys/experimental/__init__.py", "diffphys/experimental/compiled_physics.py",
                  "diffphys/experimental/strict_inductor.py")},
              "single_step_pulse_index": pulse_index, "single_step": single, "single_step_vjps": single_grad,
              "eager": meta_a, "candidate": meta_b, "trajectory": trajectory, "comparison": checks,
              "scope": "Current-source diagnostic; original Oct 5 raw fixture unavailable. No H500 graph compilation, training, checkpoint rewrite or deployment claim. Warm timings only if requested."}
    simulators = {"eager": reference, "candidate": candidate}
    if args.compare_rotation:
        rotation = RaptorSimulator(rotation_backend="compile")
        values, steps, metadata = rollout_result(rotation, policy, initial, loss, groups, args.horizon, saved)
        rotation_checks = {name: compare_tensor(a[name], value, **(state_tol if name == "costs" else grad_tol))
                           for name, value in values.items()}
        rotation_trajectory = compare_steps(steps_a, steps, state_tol)
        rotation_exact = rotation_trajectory["bitwise_equal"] and all(v["bitwise_equal"] for v in rotation_checks.values())
        rotation_passed = all(v["close"] for v in [rotation_trajectory, *rotation_checks.values()]) and (rotation_exact or not args.require_bitwise)
        report["rotation_reference"] = {"passed": rotation_passed, "zero_drift": rotation_exact,
                                        "comparison": rotation_checks, "trajectory": rotation_trajectory,
                                        "metadata": metadata}
        report["passed"] = report["passed"] and rotation_passed
        simulators["rotation"] = rotation
    print(json.dumps({"phase": "rollout_gate", "passed": report["passed"],
                      "zero_drift": zero_drift,
                      "rotation_zero_drift": report.get("rotation_reference", {}).get("zero_drift"),
                      "physical_transitions": meta_b["physical_transitions"]}), flush=True)
    if args.timing_repeats:
        if report["passed"]:
            report["timing"] = benchmark(simulators, policy, initial,
                                          loss, groups, args.horizon, args.timing_repeats)
        else:
            report["timing"] = {"skipped": "numerical gate failed"}
    if state_hash(initial) != input_hash:
        raise RuntimeError("diagnostic mutated the frozen initial state or tapes")
    atomic_json(args.report, report)
    print(json.dumps({"report": str(args.report), "passed": report["passed"],
                      "trajectory": trajectory, "comparison": checks,
                      "timing": report.get("timing")}, indent=2, allow_nan=False), flush=True)
    return report


if __name__ == "__main__":
    raise SystemExit(0 if main()["passed"] else 1)
