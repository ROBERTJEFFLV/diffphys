#!/usr/bin/env python3
"""Four restored-checkpoint scheduling schemes, with all GC debt accounted for."""
from __future__ import annotations

import argparse
import gc
import json
from pathlib import Path
import random
import statistics
import sys
import time
from unittest.mock import patch
import weakref

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import torch

from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
from diffphys.experimental.dynamic_scheduling import GCEvents, collector_for, index_fill_rollout
from diffphys.experimental.scheduled_update import complete_scheduled_update
from diffphys.response_audit import AuditConfig, UpdateAudit
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ResponseMotorPolicy, ResponsePolicyConfig
from diffphys.response_task import TaskLossConfig, rollout
from diffphys.response_training import (SOURCE_FILES, atomic_json, atomic_torch, capture_rng,
                                       file_hash, migrate_named_adam, model_hash, restore_rng,
                                       source_hash)
from tools.benchmark_rollout_scheduling import (CaseCapture, compare_captures, snapshot,
                                               values_after_update)
from tools.diagnose_rk4_compile import state_hash

EXPERIMENT_SOURCES = ('diffphys/experimental/dynamic_scheduling.py',
                      'diffphys/experimental/scheduled_update.py',
                      'diffphys/experimental/compiled_physics.py',
                      'diffphys/experimental/strict_inductor.py',
                      'tools/benchmark_dynamic_scheduling.py',
                      'tools/benchmark_rollout_scheduling.py',
                      'tools/diagnose_rk4_compile.py')
# Balanced Williams order: every treatment occurs in every position; each
# directed carryover pair occurs once per four rounds. No per-round forced GC.
ORDERS = ('ABDC', 'BCAD', 'CDBA', 'DACB')


def memory():
    rss_kib = next(int(line.split()[1]) for line in Path('/proc/self/status').read_text().splitlines()
                   if line.startswith('VmRSS:'))
    stats = torch.cuda.memory_stats()
    return {'rss_bytes': rss_kib*1024,
            'cuda_allocated_bytes': torch.cuda.memory_allocated(),
            'cuda_active_bytes': stats['active_bytes.all.current'],
            'cuda_reserved_bytes': torch.cuda.memory_reserved(),
            'cuda_peak_allocated_bytes': torch.cuda.max_memory_allocated()}


def percentile(values, fraction):
    values = sorted(values)
    point = (len(values)-1)*fraction
    low = int(point)
    high = min(low+1, len(values)-1)
    return values[low]+(point-low)*(values[high]-values[low])


def summarize(rows):
    result = {}
    for key in rows[0]:
        if not key.endswith('_seconds'):
            continue
        values = [row[key] for row in rows]
        result[key] = {'median': statistics.median(values), 'p90': percentile(values, .9),
                       'max': max(values), 'min': min(values), 'sum': sum(values),
                       'stdev': statistics.stdev(values)}
    for key in rows[0]['memory']:
        values = [row['memory'][key] for row in rows]
        result[key] = {'first':values[0], 'last':values[-1], 'min':min(values), 'max':max(values),
                       'last5_minus_first5_median':statistics.median(values[-5:])-statistics.median(values[:5])}
    return result


def paired(rows, baseline):
    rng = random.Random(704)
    result = {}
    for key in ['complete_update_seconds', 'inclusive_cycle_seconds']:
        delta = [row[key]-ref[key] for row,ref in zip(rows,baseline)]
        means = [statistics.mean(rng.choices(delta, k=len(delta))) for _ in range(5000)]
        result[key] = {'mean_delta_seconds':statistics.mean(delta),
                       'median_delta_seconds':statistics.median(delta),
                       'bootstrap_mean_95pct_interval_seconds':[percentile(means,.025),percentile(means,.975)],
                       'faster_rounds':sum(value < 0 for value in delta), 'paired_deltas_seconds':delta}
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint',type=Path,default=Path('best.pt'))
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--repeats',type=int,default=20)
    args = parser.parse_args(argv)
    if args.repeats < 10 or args.repeats % 4:
        parser.error('at least 12 repeats, divisible by 4 for balanced order')
    if args.output.exists() and any(args.output.iterdir()):
        parser.error('use an empty output directory')
    args.output.mkdir(parents=True,exist_ok=True)
    if not torch.cuda.is_available() or not gc.isenabled():
        parser.error('CUDA and initially enabled automatic GC required')
    torch.set_num_threads(1)
    torch.manual_seed(7)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    saved = torch.load(args.checkpoint,map_location='cpu',weights_only=True)
    checkpoint_sha = file_hash(args.checkpoint)
    actor = ResponseMotorPolicy(ResponsePolicyConfig(**saved['policy_config'])).cuda()
    actor.load_state_dict(saved['model'])
    assert model_hash(actor) == saved['model_sha256']
    optimizer = torch.optim.Adam(actor.parameters(),lr=3e-4)
    simulator = CompiledRaptorSimulator()
    groups = GroupBalanceConfig(max_groups=128,min_scenarios=16,layout='coverage128')
    loss = TaskLossConfig(.01,.01,25.)
    rng = capture_rng()
    collectors = {name:collector_for(index_fill_rollout if name in 'BD' else rollout) for name in 'ABCD'}
    sources = list(SOURCE_FILES)+list(EXPERIMENT_SOURCES)
    audits = {name:UpdateAudit(args.output/name,AuditConfig(),evaluation_interval=50,
                               binding={'experiment':'dynamic-bool-gc','case':name,
                                        'checkpoint_sha256':checkpoint_sha,'source_sha256':source_hash()},
                               source_root=ROOT,source_files=sources,
                               torch_writer=atomic_torch,json_writer=atomic_json) for name in 'ABCD'}
    results = {name:{'samples':[]} for name in 'ABCD'}
    initial_hash = None

    def reset():
        actor.load_state_dict(saved['model'])
        migrate_named_adam(optimizer,actor,saved['optimizer'],saved['optimizer_parameter_names'])
        restore_rng(rng)

    def update(name,collector,monitor,warmup):
        return complete_scheduled_update(actor,optimizer,simulator,collector=collector,
                                         scenes=2048,horizon=500,loss=loss,groups=groups,
                                         audit=audits[name],progress={'updates':0},
                                         history=args.output/name/'measurements.jsonl',
                                         extra_row={'warmup':warmup,'case':name},
                                         defer_gc=name in 'CD',monitor=monitor)

    with GCEvents() as monitor:
        for name in 'ABCD':
            monitor.case, monitor.trial = name, 'warmup'
            reset()
            capture = CaseCapture(actor,simulator,'dynamic')
            with capture as recorder, patch('diffphys.response_adjoints.rollout',
                                           index_fill_rollout if name in 'BD' else rollout):
                original_simulator = simulator
                simulator = recorder
                try:
                    result = update(name,capture.collector,monitor,True)
                finally:
                    simulator = original_simulator
            values = values_after_update(actor,optimizer,result)
            digest = state_hash(result['initial'])
            if name == 'A':
                reference_capture, reference_values = capture, values
                initial = snapshot(result['initial'])
                initial_hash = digest
                results[name]['numerics'] = {'passed':True,'bitwise_equal':True,'reference':True}
            else:
                results[name]['numerics'] = compare_captures(reference_capture,capture,initial,
                                                           reference_values,values)
                assert results[name]['numerics']['bitwise_equal'], name
            assert digest == initial_hash
            valid = torch.cat([chunk[0]['valid'] for chunk in capture.chunks])
            results[name]['valid_transitions'] = int(valid.sum())
            results[name]['termination_steps_bitwise_equal'] = torch.equal(
                valid.sum(0),torch.cat([chunk[0]['valid'] for chunk in reference_capture.chunks]).sum(0))
            results[name]['warmup'] = result['timings']
            print(json.dumps({'warmup':name,'bitwise':True,'valid':int(valid.sum())}),flush=True)
            del result, values, capture, valid
        torch.save(reference_values,args.output/'reference_update_values.pt')
        del reference_capture, initial, recorder
        optimizer.zero_grad(set_to_none=True)
        # One campaign setup drain removes capture/compiler objects; it precedes
        # all timed rounds. There is no forced collection between timed updates.
        monitor.stage = 'campaign_setup_drain'
        gc.collect()
        torch.cuda.synchronize()
        before_memory = memory()
        counters_before = dict(torch._dynamo.utils.counters['stats'])
        timed_start = time.perf_counter()
        events_start = len(monitor.events)
        for trial in range(args.repeats):
            for name in ORDERS[trial % 4]:
                cycle_start = time.perf_counter()
                monitor.case, monitor.trial = name, trial
                monitor.stage = name+'/reset'
                reset()
                torch.cuda.synchronize()
                reset_done = time.perf_counter()
                torch.cuda.reset_peak_memory_stats()
                result = update(name,collectors[name],monitor,False)
                assert gc.isenabled()
                timings = dict(result['timings'])
                monitor.stage = name+'/verification'
                actual = values_after_update(actor,optimizer,result)
                assert all(torch.equal(reference_values[key],value) for key,value in actual.items()), (name,trial)
                assert state_hash(result['initial']) == initial_hash
                probe = result['record'].probe
                assert probe._closed and not probe._payloads and not probe._tensor_handles and not probe._module_handles
                probe_reference = weakref.ref(probe)
                record_reference = weakref.ref(result['record'])
                verify_done = time.perf_counter()
                monitor.stage = name+'/release'
                del probe,result,actual
                optimizer.zero_grad(set_to_none=True)
                torch.cuda.synchronize()
                assert probe_reference() is None and record_reference() is None
                metrics = memory()
                row = {**timings,'trial':trial,'initial_sha256':initial_hash,'bitwise_equal':True,
                       'probe_and_record_released':True,'memory':metrics,
                       'reset_seconds':reset_done-cycle_start,
                       'verification_seconds':verify_done-reset_done-timings['complete_update_seconds'],
                       'release_and_telemetry_seconds':time.perf_counter()-verify_done}
                monitor.stage = name+'/coordinator'
                results[name]['samples'].append(row)
                print(json.dumps({'case':name,'trial':trial,'update_s':timings['complete_update_seconds'],
                                  'allocated_MiB':metrics['cuda_allocated_bytes']/2**20}),flush=True)
                row['inclusive_cycle_seconds'] = time.perf_counter()-cycle_start
        monitor.case, monitor.trial = None, None
        monitor.stage = 'terminal_debt_drain'
        drain_start = time.perf_counter()
        collected = gc.collect()
        torch.cuda.synchronize()
        terminal_drain = time.perf_counter()-drain_start
        after_memory = memory()
        total = time.perf_counter()-timed_start
        events = monitor.events[events_start:]
        counters_after = dict(torch._dynamo.utils.counters['stats'])
    assert counters_after.get('unique_graphs',0) == counters_before.get('unique_graphs',0)
    assert file_hash(args.checkpoint) == checkpoint_sha
    for name in 'ABCD':
        results[name]['summary'] = summarize(results[name]['samples'])
        results[name]['inclusive_sum_plus_entire_terminal_drain_seconds'] = (
            results[name]['summary']['inclusive_cycle_seconds']['sum']+terminal_drain)
        if name != 'A':
            results[name]['paired_vs_A'] = paired(results[name]['samples'],results['A']['samples'])
    atomic_json(args.output/'gc_events.json',events)
    report = {'cases':results,'checkpoint_sha256':checkpoint_sha,'initial_sha256':initial_hash,
              'source_sha256':source_hash(),'experimental_sources':{s:file_hash(ROOT/s) for s in EXPERIMENT_SOURCES},
              'torch':str(torch.__version__),'device':torch.cuda.get_device_name(),'gc_thresholds':gc.get_threshold(),
              'compiler_counters_before':counters_before,'compiler_counters_after':counters_after,
              'budget':{'warmup_per_case':1,'timed_per_case':args.repeats,'total_updates':4*(args.repeats+1)},
              'order':ORDERS,'campaign':{'total_seconds':total,'terminal_drain_seconds':terminal_drain,
                                        'terminal_drain_collected':collected,'before_memory':before_memory,
                                        'after_memory':after_memory,
                                        'sum_inclusive_cycles_seconds':sum(r['inclusive_cycle_seconds'] for c in results.values() for r in c['samples'])},
              'scope':'Complete updates include backup/sampling/forward/backward/clipping/Adam/audit/history. Inclusive cycles also charge reset, exact numerical verification and release. All timed trials share one interleaved process and GC debt; final full drain is charged to the campaign and conservatively to each scheme separately. No forced collection per update. Periodic EVAL/checkpoints excluded.'}
    atomic_json(args.output/'report.json',report)
    print(json.dumps({'report':str(args.output/'report.json'),'updates':4*(args.repeats+1),
                      'campaign_seconds':total,'terminal_drain_seconds':terminal_drain}),flush=True)


if __name__ == '__main__':
    main()
