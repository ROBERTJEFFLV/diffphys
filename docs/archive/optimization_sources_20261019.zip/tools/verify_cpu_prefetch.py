#!/usr/bin/env python3
"""Offline C/P chain and H500 checks, including the actual spawned CPU boundary."""
from __future__ import annotations

import argparse
from dataclasses import replace
import gc
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import torch

from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
from diffphys.experimental.continuous_training import critical_gc
from diffphys.experimental.scene_prefetch import ScenePrefetch
from diffphys.response_adjoints import backward_actor
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ResponseMotorPolicy, ResponsePolicyConfig
from diffphys.response_task import TaskLossConfig
from diffphys.response_training import atomic_json, restore_rng, safe_global_clip, sample_training_scenarios
from tools.benchmark_rollout_scheduling import CaseCapture, compare_captures, snapshot
from tools.verify_compiled_continuity import exact, capsules


def verify_chains(root: Path, updates: int):
    folders={name:root/'runs'/name for name in ['C','P','P_split']}
    paths={name:capsules(folder) for name,folder in folders.items()}
    assert all(sorted(rows)==list(range(1,updates+1)) for rows in paths.values())
    prior={}; seeds=[]; changed={name:0 for name in paths}
    for number in range(1,updates+1):
        current={name:torch.load(rows[number],map_location='cpu',weights_only=True)
                 for name,rows in paths.items()}
        for name,value in current.items():
            assert value['failure'] is None and value['before']['sampling_index']==number-1
            if name in prior:
                for field in ['model','optimizer','rng']:
                    exact(prior[name][field],value['before'][field],f'{name}/{number}/continuity/{field}')
            for field in ['before','after','sampling','groups','gradients_entering_adam','parameter_changes']:
                exact(current['C'][field],value[field],f'{name}/{number}/vs_C/{field}')
            for key,state in value['after']['optimizer']['state'].items():
                assert state['step'].item()==value['before']['optimizer']['state'][key]['step'].item()+1
            changed[name]+=int(value['parameter_changes']['l2']>0)
            prior[name]=value['after']
        seeds.append(tuple(current['C']['sampling']['seeds']))
        if number%25==0:print({'state_chain_verified_through':number},flush=True)
    assert len(set(seeds))==updates and all(n==updates for n in changed.values())
    final={name:torch.load(folder/'latest.pt',map_location='cpu',weights_only=True)
           for name,folder in folders.items()}
    for name,value in final.items():
        assert value['next_update']==value['progress']['sampling_index']==value['progress']['updates']==updates
        for field in ['model','optimizer','rng']:
            exact(final['C'][field],value[field],name+'/final/'+field)
        for field in ['updates','sampling_index','status','initialization']:
            exact(final['C']['progress'][field],value['progress'][field],name+'/progress/'+field)
        assert value['cleanup']['closed_probes']
        assert value['cleanup']['gc_enabled']==value['cleanup']['entry_gc_enabled']
        if name!='C':
            assert value['cleanup']['worker_closed']
            assert not Path(f'/proc/{value["cleanup"]["worker_pid"]}').exists()
    mid=torch.load(root/f'P_split_{updates//2}.pt',map_location='cpu',weights_only=True)
    assert mid['next_update']==updates//2
    cap=torch.load(paths['P'][updates//2],map_location='cpu',weights_only=True)
    for field in ['model','optimizer','rng']:
        exact(mid[field],cap['after'][field],'split_midpoint/'+field)
    atomic_json(root/'state_chain_comparison.json',{
        'passed':True,'updates_per_run':updates,'total_actual_updates':3*updates,
        'all_per_update_actor_adam_main_rng_sampling_groups_final_gradients_raw_bytes_equal':True,
        'fresh_process_resume_final_exact':True,'midpoint_saved_checkpoint_exact':True,
        'unique_sampling_indices':updates,'updates_with_nonzero_parameter_change':changed,
        'final_model_sha256':final['C']['model_sha256']})
    return paths


def replay(root: Path, paths, updates: int):
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    simulator=CompiledRaptorSimulator()
    reports={}
    worker=ScenePrefetch(512,horizon=500,threads=1)
    try:
        for number in sorted({1,updates//2,updates//2+1,updates}):
            captures={}; values={}; initials={}
            for name in ['C','P']:
                saved=torch.load(paths[name][number],map_location='cpu',weights_only=True)
                actor=ResponseMotorPolicy(ResponsePolicyConfig(**saved['policy_config'])).cuda()
                actor.load_state_dict(saved['before']['model'])
                restore_rng(saved['before']['rng'])
                if name=='P':
                    worker.submit(number-1)
                    cpu,seeds,report,stats=worker.take(number-1)
                    exact(report,saved['sampling']['report'])
                    initial=cpu.to('cuda',torch.float32)
                    del cpu
                else:
                    initial,seeds=sample_training_scenarios(512,number-1,sampling='coverage128',
                                                           device='cuda',horizon=500)
                exact(seeds,saved['sampling']['seeds'])
                initials[name]=snapshot(initial)
                capture=CaseCapture(actor,simulator,'dynamic')
                groups=GroupBalanceConfig(**saved['binding']['groups'])
                loss=TaskLossConfig(**saved['binding']['loss'])
                with capture as recorder,critical_gc(True):
                    record=capture.collector(actor,recorder,initial,loss,horizon=500,
                                             time_decay=1.,group_config=groups)
                    backward=backward_actor(actor,recorder,record,loss)
                    record=replace(record,costs=record.costs.detach())
                safe_global_clip(actor.parameters(),10.)
                for param_name,p in actor.named_parameters():
                    exact(p.grad.detach().cpu(),saved['gradients_entering_adam'][param_name],
                          f'{name}/{number}/audit_gradient/'+param_name)
                values[name]={'costs':record.costs.detach().cpu().clone(),
                              'raw_group_gradients':record.probe.rows.detach().cpu().clone(),
                              'group_norms_and_multipliers':backward['group_gradient']['values'].detach().cpu().clone(),
                              'gradient_entering_adam':torch.cat([p.grad.flatten().cpu() for p in actor.parameters()])}
                captures[name]=capture
                del record,backward,initial,saved,actor
            exact(initials['C'],initials['P'],str(number)+'/initial')
            for attribute in ['inputs','outputs','memories','chunks']:
                exact(getattr(captures['C'],attribute),getattr(captures['P'],attribute),
                      str(number)+'/H500/'+attribute)
            exact(values['C'],values['P'],str(number)+'/replay_gradients')
            check=compare_captures(captures['C'],captures['P'],initials['C'],values['C'],values['P'])
            check['raw_bytes_equal']=True
            reports[str(number)]=check
            assert check['bitwise_equal'],number
            atomic_json(root/'key_h500_comparison.json',{'passed':True,'updates':reports,'optimizer_calls':0,
                'scope':'Actual audit inputs, P data generated by spawn CPU worker. Outside performance timing.'})
            print({'H500_replay_update':number,'raw_bytes_equal':True},flush=True)
            del captures,values,initials,capture,recorder
            gc.collect()
            torch.cuda.synchronize()
    finally:
        worker.close()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--updates',type=int,default=100)
    parser.add_argument('--state-only',action='store_true')
    args=parser.parse_args()
    paths=verify_chains(args.root,args.updates)
    if not args.state_only:replay(args.root,paths,args.updates)


if __name__=='__main__':main()
