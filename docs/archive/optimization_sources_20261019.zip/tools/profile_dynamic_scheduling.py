#!/usr/bin/env python3
"""Capture the isolated bool-fill experiment using the original NVTX probe."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from diffphys.experimental.dynamic_scheduling import index_fill_rollout
from diffphys.response_training import atomic_json
from tools.profile_rollout_scheduling import capture


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--index-fill',action='store_true')
    parser.add_argument('--checkpoint',type=Path,default=Path('best.pt'))
    parser.add_argument('--scenes',type=int,default=2048)
    parser.add_argument('--horizon',type=int,default=500)
    parser.add_argument('--report',type=Path,required=True)
    args = parser.parse_args(argv)
    args.schedule = 'dynamic'
    if args.index_fill:
        with patch('diffphys.response_task.rollout',index_fill_rollout), \
                patch('diffphys.response_adjoints.rollout',index_fill_rollout):
            result = capture(args)
    else:
        result = capture(args)
    result['index_fill'] = args.index_fill
    atomic_json(args.report,result)
    print({'report':str(args.report),'index_fill':args.index_fill,
           'bare_seconds':result['bare_seconds'],'profiled_seconds':result['profiled_seconds']},flush=True)


if __name__ == '__main__':
    main()
