#!/usr/bin/env python3
"""Offline exact state-chain and H500 replay checks; never call Adam."""
from __future__ import annotations

import argparse
from dataclasses import replace
import gc
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

import torch

from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
from diffphys.experimental.continuous_training import critical_gc
from diffphys.response_adjoints import backward_actor
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ResponseMotorPolicy,ResponsePolicyConfig
from diffphys.response_task import TaskLossConfig
from diffphys.response_training import (atomic_json,model_hash,restore_rng,safe_global_clip,
                                       sample_training_scenarios)
from tools.benchmark_rollout_scheduling import CaseCapture,compare_captures,snapshot
from tools.diagnose_rk4_compile import state_hash


def exact(a,b,path='root'):
    if torch.is_tensor(a):
        if (a.dtype != b.dtype or a.shape != b.shape
                or not torch.equal(a.contiguous().reshape(-1).view(torch.uint8),
                                   b.contiguous().reshape(-1).view(torch.uint8))):
            raise AssertionError('tensor mismatch: '+path)
    elif isinstance(a,dict):
        if a.keys()!=b.keys():raise AssertionError('keys mismatch: '+path)
        for key in a:exact(a[key],b[key],path+'/'+str(key))
    elif isinstance(a,(list,tuple)):
        if len(a)!=len(b):raise AssertionError('length mismatch: '+path)
        for index,(x,y) in enumerate(zip(a,b)):exact(x,y,path+'/'+str(index))
    elif a!=b:raise AssertionError('value mismatch: '+path)


def capsules(work):
    values={}
    for path in (work/'audit/updates').glob('*.pt'):
        number=int(path.name.split('_')[0][1:])
        if number in values:raise AssertionError('duplicate update '+str(number))
        values[number]=path
    return values


def verify_chains(root):
    folders={name:root/'runs'/name for name in ['A','C','C_split']}
    paths={name:capsules(folder) for name,folder in folders.items()}
    assert all(sorted(rows)==list(range(1,201)) for rows in paths.values())
    prior={};seeds=[];changed={name:0 for name in paths}
    for number in range(1,201):
        current={name:torch.load(rows[number],map_location='cpu',weights_only=True) for name,rows in paths.items()}
        ref=current['A']
        for name,capsule in current.items():
            assert capsule['failure'] is None and capsule['before']['sampling_index']==number-1
            if name in prior:
                for field in ['model','optimizer','rng']:
                    exact(prior[name][field],capsule['before'][field],f'{name}/{number}/continuity/{field}')
            for field in ['before','after','sampling','groups','gradients_entering_adam','parameter_changes']:
                exact(ref[field],capsule[field],f'{name}/{number}/vs_A/{field}')
            for key,state in capsule['after']['optimizer']['state'].items():
                assert state['step'].item()==78950+number
                assert state['step'].item()==capsule['before']['optimizer']['state'][key]['step'].item()+1
            changed[name]+=int(capsule['parameter_changes']['l2']>0)
            prior[name]=capsule['after']
        seeds.append(tuple(ref['sampling']['seeds']))
        if number%25==0:print({'state_chain_verified_through':number},flush=True)
    assert len(set(seeds))==200
    final={name:torch.load(folder/'latest.pt',map_location='cpu',weights_only=True) for name,folder in folders.items()}
    for name,value in final.items():
        assert value['next_update']==value['progress']['sampling_index']==value['progress']['updates']==200
        for field in ['model','optimizer','rng']:
            exact(final['C'][field],value[field],name+'/final/'+field)
        actual={key:val for key,val in value['progress'].items() if key!='elapsed_seconds'}
        expected={key:val for key,val in final['C']['progress'].items() if key!='elapsed_seconds'}
        exact(expected,actual,name+'/final/progress')
        assert value['cleanup']['closed_probes'] and value['cleanup']['gc_enabled']==value['cleanup']['entry_gc_enabled']
    report={'passed':True,'updates_per_run':200,'total_actual_updates':600,
            'all_per_update_before_after_actor_adam_rng_sampling_group_reports_gradients_bitwise':True,
            'fresh_process_resume_final_exact':True,'unique_sampling_indices':200,
            'updates_with_nonzero_parameter_change':changed,
            'final_model_sha256':final['C']['model_sha256'],
            'limits':'Only elapsed wall clocks and experiment binding scheme differ; algorithmic progress is exact.'}
    atomic_json(root/'state_chain_comparison.json',report)
    return paths


def replay(root,paths):
    torch.set_num_threads(1)
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    simulator=CompiledRaptorSimulator()
    reports={}
    for number in [1,50,100,150,200]:
        captures={};values={};initials={}
        for name in ['A','C']:
            saved=torch.load(paths[name][number],map_location='cpu',weights_only=True)
            actor=ResponseMotorPolicy(ResponsePolicyConfig(**saved['policy_config'])).cuda()
            actor.load_state_dict(saved['before']['model'])
            restore_rng(saved['before']['rng'])
            initial,seeds=sample_training_scenarios(512,number-1,sampling='coverage128',device='cuda',horizon=500)
            exact(seeds,saved['sampling']['seeds'])
            initials[name]=snapshot(initial)
            capture=CaseCapture(actor,simulator,'dynamic')
            groups=GroupBalanceConfig(**saved['binding']['groups'])
            loss=TaskLossConfig(**saved['binding']['loss'])
            with capture as recorder,critical_gc(name=='C'):
                record=capture.collector(actor,recorder,initial,loss,horizon=500,time_decay=1.,group_config=groups)
                backward=backward_actor(actor,recorder,record,loss)
                if name=='C':record=replace(record,costs=record.costs.detach())
            safe_global_clip(actor.parameters(),10.)
            for param_name,p in actor.named_parameters():
                exact(p.grad.detach().cpu(),saved['gradients_entering_adam'][param_name],f'{name}/{number}/audit_gradient/'+param_name)
            values[name]={'costs':record.costs.detach().cpu().clone(),
                          'raw_group_gradients':record.probe.rows.detach().cpu().clone(),
                          'group_norms_and_multipliers':backward['group_gradient']['values'].detach().cpu().clone(),
                          'gradient_entering_adam':torch.cat([p.grad.flatten().cpu() for p in actor.parameters()])}
            captures[name]=capture
            del record,backward,initial,saved,actor
        for attribute in ['inputs','outputs','memories','chunks']:
            exact(getattr(captures['A'],attribute),getattr(captures['C'],attribute),
                  str(number)+'/H500/'+attribute)
        exact(values['A'],values['C'],str(number)+'/replay_gradients')
        check=compare_captures(captures['A'],captures['C'],initials['A'],values['A'],values['C'])
        check['raw_bytes_equal'] = True
        reports[str(number)]=check
        atomic_json(root/'key_h500_comparison.json',{'passed':all(c['bitwise_equal'] for c in reports.values()),'updates':reports,'optimizer_calls':0,
                                                   'scope':'Frozen replay from actual per-update audit inputs; outside performance timings.'})
        assert check['bitwise_equal'],number
        print({'H500_replay_update':number,'bitwise_equal':True},flush=True)
        del captures,values,initials,capture,recorder
        gc.collect()
        torch.cuda.synchronize()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,required=True)
    parser.add_argument('--state-only',action='store_true')
    args=parser.parse_args()
    paths=verify_chains(args.root)
    if not args.state_only:replay(args.root,paths)


if __name__=='__main__':main()
