"""The experimental step must preserve the original state and autograd boundary."""
from __future__ import annotations

from dataclasses import asdict, fields, replace

import pytest
import torch

from diffphys.env_raptor import RaptorSimulator


@pytest.fixture(autouse=True)
def isolate_compiler_variants():
    # Independent backends/devices/dtypes must not exhaust one shared code cache.
    torch._dynamo.reset()
    yield
    torch._dynamo.reset()


def test_strict_backend_preserves_native_arithmetic_without_global_lowering_changes():
    from torch._inductor.decomposition import decompositions
    from torch._inductor.lowering import lowerings, fallbacks
    from diffphys.experimental.strict_inductor import strict_inductor

    before = dict(lowerings), dict(decompositions), set(fallbacks)

    def arithmetic(x, y):
        products = x * y
        cross = torch.linalg.cross(x[:, :3], y[:, :3], dim=-1)
        norm = torch.linalg.vector_norm(x, dim=-1)
        matrix = x[:, :3, None] @ y[:, None, :3]
        return products.sum(-1), cross, norm, matrix

    x = torch.tensor([[1e8, 1., -1e8, 1.], [.07, -.13, .71, .91]], requires_grad=True)
    y = torch.tensor([[1., 1., 1., 1.], [.19, .23, -.31, .89]], requires_grad=True)
    expected = arithmetic(x, y)
    actual = torch.compile(arithmetic, backend=strict_inductor, fullgraph=True)(x, y)
    for a, b in zip(actual, expected):
        torch.testing.assert_close(a, b, rtol=0, atol=0)
    expected_grad = torch.autograd.grad(sum(t.square().sum() for t in expected), (x, y))
    actual_grad = torch.autograd.grad(sum(t.square().sum() for t in actual), (x, y))
    for a, b in zip(actual_grad, expected_grad):
        torch.testing.assert_close(a, b, rtol=1e-6, atol=1e-6)
    assert lowerings == before[0]
    assert decompositions == before[1]
    assert fallbacks == before[2]


@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_strict_compiled_step_matches_original_pulse_vjps_and_compaction(device):
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA unavailable")
    from diffphys.experimental.compiled_physics import CompiledRaptorSimulator
    from tools.diagnose_rk4_compile import one_step
    from diffphys.response_training import sample_training_scenarios

    state, _ = sample_training_scenarios(32, 0, horizon=16, sampling="coverage128", device=device)
    expected, expected_grad, _ = one_step(RaptorSimulator(), state)
    simulator = CompiledRaptorSimulator(backend="compiled")
    actual, actual_grad, _ = one_step(simulator, state)
    for name in expected:
        torch.testing.assert_close(actual[name], expected[name], rtol=0, atol=0)
    for name in expected_grad:
        torch.testing.assert_close(actual_grad[name], expected_grad[name], rtol=1e-5, atol=1e-6)
    shrunk = replace(state, **{field.name: getattr(state, field.name)[:7]
                              for field in fields(state)
                              if field.name not in ("noise_tape", "rotation_tape", "pulse_tape", "pulse_active_tape")})
    action = torch.full_like(shrunk.motor, .13, requires_grad=True)
    expected_state = RaptorSimulator().step(shrunk, action)
    actual_state = simulator.step(shrunk, action)
    for field in fields(state):
        torch.testing.assert_close(getattr(actual_state, field.name), getattr(expected_state, field.name), rtol=0, atol=0)
    for name in ("noise_tape", "rotation_tape", "pulse_tape", "pulse_active_tape"):
        assert getattr(actual_state, name) is getattr(state, name)


def test_experimental_backend_compiles_original_step_and_preserves_history():
    from diffphys.experimental.compiled_physics import CompiledRaptorSimulator

    eager = RaptorSimulator()
    compiled = CompiledRaptorSimulator(backend="aot_eager")
    state = eager.reset(4, seed=73, horizon=3, dtype=torch.float64)
    names = ("position", "velocity", "orientation", "omega", "motor", "previous_velocity")
    state = replace(state, **{name: getattr(state, name).requires_grad_() for name in names})
    action = torch.full_like(state.motor, .13, requires_grad=True)
    inputs = [getattr(state, name) for name in names] + [action]
    reference, actual = eager.step(state, action), compiled.step(state, action)
    for field in fields(state):
        torch.testing.assert_close(getattr(actual, field.name), getattr(reference, field.name), rtol=0, atol=0)
    for name in ("noise_tape", "rotation_tape", "pulse_tape", "pulse_active_tape"):
        assert getattr(actual, name) is getattr(state, name)
    gradients = [torch.autograd.grad(sum(getattr(value, name).square().sum() for name in names), inputs)
                 for value in (reference, actual)]
    for reference_grad, actual_grad in zip(*gradients):
        torch.testing.assert_close(actual_grad, reference_grad, rtol=3e-9, atol=2e-10)
    # Survivor compaction must not slice the immutable original-pool tapes.
    shrunk = replace(state, **{field.name: getattr(state, field.name)[:2]
                              for field in fields(state)
                              if field.name not in ("noise_tape", "rotation_tape", "pulse_tape", "pulse_active_tape")})
    reference, actual = eager.step(shrunk, action[:2]), compiled.step(shrunk, action[:2])
    for field in fields(state):
        torch.testing.assert_close(getattr(actual, field.name), getattr(reference, field.name), rtol=0, atol=0)


def test_experimental_backend_rejects_bad_actions_and_does_not_hide_compiler_errors():
    from diffphys.experimental.compiled_physics import CompiledRaptorSimulator

    simulator = CompiledRaptorSimulator(backend="eager")
    state = simulator.reset(4, seed=5, horizon=1)
    with pytest.raises(ValueError, match="action must match"):
        simulator.step(state, state.motor[:, :3])

    def broken_backend(graph, inputs):
        raise RuntimeError("deliberate compiler failure")

    simulator = CompiledRaptorSimulator(backend=broken_backend)
    with pytest.raises(Exception, match="deliberate compiler failure"):
        simulator.step(state, state.motor)


def test_diagnostic_rejects_nonfinite_and_shape_mismatch():
    from tools.diagnose_rk4_compile import compare_tensor

    reference = torch.tensor([1., 2.])
    assert compare_tensor(reference, reference.clone(), rtol=1e-6, atol=1e-6)["close"]
    assert not compare_tensor(reference, torch.tensor([1., float("nan")]), rtol=1e-6, atol=1e-6)["close"]
    assert not compare_tensor(reference, reference[:1], rtol=1e-6, atol=1e-6)["close"]
    assert not compare_tensor(reference, reference + .01, rtol=1e-6, atol=1e-6)["close"]


@pytest.mark.parametrize("backend", ["aot_eager", "rotation", "compiled"])
def test_diagnostic_runs_real_group_backward_and_writes_report(tmp_path, backend):
    from tools.diagnose_rk4_compile import main
    from diffphys.response_policy import ARCHITECTURE, ResponseMotorPolicy
    from diffphys.response_training import model_hash, optimizer_parameter_names

    policy = ResponseMotorPolicy()
    optimizer = torch.optim.Adam(policy.parameters(), lr=2e-4)
    for parameter in policy.parameters():
        parameter.grad = torch.full_like(parameter, .01)
    optimizer.step()
    checkpoint = tmp_path / "actor.pt"
    torch.save({"architecture": ARCHITECTURE, "policy_config": asdict(policy.config),
                "model": policy.state_dict(), "model_sha256": model_hash(policy),
                "optimizer": optimizer.state_dict(),
                "optimizer_parameter_names": optimizer_parameter_names(policy, optimizer)}, checkpoint)
    before = checkpoint.read_bytes()
    report = main(["--device", "cpu", "--backend", backend, "--dtype", "float64",
                   "--scenes", "128", "--sampling", "coverage128", "--horizon", "2",
                   "--checkpoint", str(checkpoint),
                   "--timing-repeats", "1",
                   *(["--compare-rotation"] if backend == "compiled" else []),
                   "--epsilon-p", ".01", "--epsilon-a", ".01", "--lambda-R", "25",
                   "--report", str(tmp_path / "diagnostic.json")])
    assert report["passed"]
    assert report["comparison"]["raw_group_gradients"]["close"]
    assert report["comparison"]["adam_exp_avg_sq"]["close"]
    assert report["eager"]["physical_transitions"] == 256
    assert report["eager"]["shadow_adam_step_after"] == 2
    assert report["candidate"]["shadow_adam_step_after"] == 2
    assert report["shadow_adam_lr"] == 2e-4
    assert checkpoint.read_bytes() == before
    assert report["timing"]["median_seconds"]["candidate"] > 0
    assert report["timing"]["samples"]["candidate"][0]["physical_transitions"] == 256
    if backend == "compiled":
        assert report["require_bitwise"]
        assert report["zero_drift"]
        assert report["rotation_reference"]["passed"]
        assert report["timing"]["median_seconds"]["rotation"] > 0
    assert (tmp_path / "diagnostic.json").is_file()


def test_bitwise_qualification_rejects_small_drift_and_skips_timing(tmp_path):
    from tools.diagnose_rk4_compile import main

    report = main(["--device", "cpu", "--backend", "inductor", "--scenes", "128",
                   "--horizon", "1", "--require-bitwise", "--timing-repeats", "1",
                   "--epsilon-p", ".01", "--epsilon-a", ".01", "--lambda-R", "25",
                   "--report", str(tmp_path / "rejected.json")])
    assert all(v["close"] for v in report["comparison"].values())
    assert all(v["close"] for v in [*report["single_step"].values(), *report["single_step_vjps"].values()])
    assert report["trajectory"]["close"]
    assert not report["zero_drift"]
    assert not report["passed"]
    assert report["timing"] == {"skipped": "numerical gate failed"}
