"""A fixed batch must retain first failure, frozen storage and training adjoints."""
from __future__ import annotations

import copy
from dataclasses import fields, replace

import pytest
import torch

from diffphys.env_raptor import IMMUTABLE_TAPES, RaptorSimulator
from diffphys.response_policy import ResponseMotorPolicy, ResponsePolicyState
from diffphys.response_task import (PHYSICAL_DYNAMIC, ResponseClosedLoopState,
                                   TaskLossConfig, initialize, rollout, task_loss)


def mixed_failures(simulator, horizon=6):
    state = simulator.reset(8, seed=41, horizon=horizon, dtype=torch.float64)
    position = torch.zeros_like(state.position)
    position[0, 0] = 1.
    velocity = torch.zeros_like(state.velocity)
    velocity[:, 0] = 1.
    limits = torch.full_like(state.position_limit, 10.)
    limits[:3] = torch.tensor([.1, .001, .015], dtype=limits.dtype)
    return replace(state, position=position, velocity=velocity, position_limit=limits,
                   previous_velocity=velocity[:, None].expand(-1, 3, -1).clone())


@pytest.mark.parametrize("time_decay", [0., 1.3])
@pytest.mark.parametrize("device", ["cpu", "cuda"])
def test_masked_rollout_preserves_failure_history_and_all_state_gradients(time_decay, device):
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA unavailable")
    from diffphys.experimental.masked_rollout import masked_rollout

    torch.manual_seed(17)
    simulator = RaptorSimulator()
    initial = mixed_failures(simulator).to(device, torch.float64)
    actor = ResponseMotorPolicy().to(device=device, dtype=torch.float64)
    results, gradients = [], []
    for implementation in (rollout, masked_rollout):
        policy = copy.deepcopy(actor)
        state = replace(initial, **{name: getattr(initial, name).clone().requires_grad_()
                                    for name in PHYSICAL_DYNAMIC})
        memory = torch.zeros(8, 64, device=device, dtype=torch.float64, requires_grad=True)
        trace = implementation(policy, simulator, ResponseClosedLoopState(state, ResponsePolicyState(memory)),
                               6, time_decay=time_decay)
        objective = task_loss(trace, TaskLossConfig(.01, .01, 25.))
        inputs = [*policy.parameters(), *(getattr(state, name) for name in PHYSICAL_DYNAMIC), memory]
        gradients.append(torch.autograd.grad(objective, inputs, allow_unused=True))
        results.append(trace)
    a, b = results
    assert not a.valid[:, 0].any()
    assert a.valid[0, 1] and not a.valid[1:, 1].any()
    assert a.valid[:2, 2].all() and not a.valid[2:, 2].any()
    for field in fields(a):
        value = getattr(a, field.name)
        if torch.is_tensor(value):
            torch.testing.assert_close(getattr(b, field.name), value, rtol=3e-9, atol=2e-10)
    for lhs, rhs in ((a.end.physical, b.end.physical), (a.end.policy, b.end.policy)):
        for field in fields(lhs):
            torch.testing.assert_close(getattr(rhs, field.name), getattr(lhs, field.name), rtol=3e-9, atol=2e-10)
    for name in IMMUTABLE_TAPES:
        assert getattr(b.end.physical, name) is getattr(initial, name)
    for lhs, rhs in zip(*gradients):
        assert (lhs is None) == (rhs is None)
        if lhs is not None:
            torch.testing.assert_close(rhs, lhs, rtol=3e-9, atol=2e-10)


def test_masked_rollout_all_terminal_rows_remain_frozen_across_chunks():
    from diffphys.experimental.masked_rollout import masked_rollout

    torch.manual_seed(19)
    simulator = RaptorSimulator()
    state = mixed_failures(simulator, horizon=8)
    state = replace(state, position_limit=torch.full_like(state.position_limit, .0001))
    policy = ResponseMotorPolicy().double()
    for implementation in (rollout, masked_rollout):
        a = implementation(policy, simulator, state, 4, time_decay=1.)
        b = implementation(policy, simulator, a.end, 4, time_decay=1.)
        assert not b.valid.any()
        for full, frozen in ((a.end.physical, b.end.physical), (a.end.policy, b.end.policy)):
            for field in fields(full):
                torch.testing.assert_close(getattr(frozen, field.name), getattr(full, field.name), rtol=0, atol=0)


def test_masked_collector_preserves_native_group_rows_and_clipped_gradient():
    from diffphys.experimental.masked_rollout import collect_masked_rollout
    from diffphys.response_adjoints import collect_rollout, backward_actor
    from diffphys.response_groups import GroupBalanceConfig
    from diffphys.response_training import sample_training_scenarios

    torch.manual_seed(23)
    initial, _ = sample_training_scenarios(32, 0, horizon=4, sampling="coverage128", dtype=torch.float64)
    # Force a subset to terminate during the first transition, not at reset.
    limits = torch.full_like(initial.position_limit, 1000.)
    position = initial.position.clone()
    position[:16] = 0.
    limits[:16] = .0001
    velocity = initial.velocity.clone()
    velocity[:16] = 1.
    initial = replace(initial, position=position, position_limit=limits, velocity=velocity)
    actor = ResponseMotorPolicy().double()
    loss = TaskLossConfig(.01, .01, 25.)
    groups = GroupBalanceConfig(max_groups=128, min_scenarios=1, layout="coverage128", clip_norm=1e-4)
    values = []
    for collector in (collect_rollout, collect_masked_rollout):
        policy = copy.deepcopy(actor)
        record = collector(policy, RaptorSimulator(), initial, loss, horizon=4,
                           time_decay=1., group_config=groups)
        report = backward_actor(policy, RaptorSimulator(), record, loss)
        assert (report["group_gradient"]["values"][:, 2] < 1).any()
        values.append((record.costs, record.probe.rows, torch.cat([p.grad.flatten() for p in policy.parameters()]), record.metrics))
    for a, b in zip(values[0][:3], values[1][:3]):
        torch.testing.assert_close(b, a, rtol=3e-9, atol=2e-10)
    assert values[0][3]["physical_transitions"] == values[1][3]["physical_transitions"] == 464


def test_masked_inner_loop_has_no_nonzero_or_per_step_scalar_reads():
    from collections import Counter
    from torch.utils._python_dispatch import TorchDispatchMode
    from diffphys.experimental.masked_rollout import masked_rollout

    class Operations(TorchDispatchMode):
        def __init__(self):
            super().__init__()
            self.calls = Counter()

        def __torch_dispatch__(self, func, types, args=(), kwargs=None):
            self.calls[str(func)] += 1
            return func(*args, **(kwargs or {}))

    simulator = RaptorSimulator()
    state = mixed_failures(simulator)
    policy = ResponseMotorPolicy().double()
    with Operations() as compact:
        rollout(policy, simulator, state, 6, time_decay=1.)
    with Operations() as masked:
        masked_rollout(policy, simulator, state, 6, time_decay=1.)
    assert compact.calls["aten.nonzero.default"] == 7
    assert masked.calls["aten.nonzero.default"] == 0
    assert masked.calls["aten._local_scalar_dense.default"] <= 1  # Original tape preflight.
