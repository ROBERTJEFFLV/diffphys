"""Continuous learning state, strict resume and exact cleanup contracts."""
from __future__ import annotations

from dataclasses import replace
import gc
import json
from pathlib import Path
import signal
import subprocess
import sys
import time

import pytest
import torch

from diffphys.env_raptor import ACTION_CONVENTION
from diffphys.response_policy import ResponseMotorPolicy
from diffphys.response_training import _checkpoint


def donor(path):
    torch.manual_seed(17)
    actor = ResponseMotorPolicy()
    optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
    for p in actor.parameters():
        p.grad = torch.full_like(p, .01)
    optimizer.step()
    torch.save(_checkpoint(actor, optimizer, {'updates': 1},
                           {'protocol': {'environment': {'action_convention': ACTION_CONVENTION}}}), path)
    return path


def config(scheme='C', updates=3):
    from diffphys.experimental.continuous_training import CandidateConfig
    return CandidateConfig(scheme=scheme, device='cpu', scenes=128, horizon=3,
                           updates=updates, checkpoint_every=1)


def exact(a, b):
    if torch.is_tensor(a):
        assert torch.equal(a, b)
    elif isinstance(a, dict):
        assert a.keys() == b.keys()
        for k in a:
            exact(a[k], b[k])
    elif isinstance(a, (list, tuple)):
        assert len(a) == len(b)
        for x,y in zip(a,b):
            exact(x,y)
    else:
        assert a == b


def test_three_continuous_updates_and_resume_keep_adam_rng_and_sampling(tmp_path):
    from diffphys.experimental.continuous_training import run
    seed = donor(tmp_path/'donor.pt')
    full, split, baseline = tmp_path/'full', tmp_path/'split', tmp_path/'A'
    run(config(), full, donor=seed)
    run(config(), split, donor=seed, stop_after=1)
    run(config(), split, resume=split/'latest.pt')
    run(config('A'), baseline, donor=seed)
    a = torch.load(full/'latest.pt', weights_only=True)
    for folder in [split, baseline]:
        b = torch.load(folder/'latest.pt', weights_only=True)
        for field in ['model', 'optimizer', 'rng', 'next_update']:
            exact(a[field], b[field])
        assert b['progress']['updates'] == b['progress']['sampling_index'] == 3
    rows = [json.loads(line) for line in (full/'history.jsonl').read_text().splitlines()]
    assert [r['update'] for r in rows] == [1, 2, 3]
    assert len({tuple(r['train_seeds']) for r in rows}) == 3
    capsules = sorted((full/'audit/updates').glob('*.pt'))
    prior = None
    for number,path in enumerate(capsules):
        capsule = torch.load(path, weights_only=True)
        if prior is not None:
            exact(prior['model'], capsule['before']['model'])
            exact(prior['optimizer'], capsule['before']['optimizer'])
        assert capsule['before']['sampling_index'] == number
        assert all(s['step'].item() == number+2 for s in capsule['after']['optimizer']['state'].values())
        prior = capsule['after']


def test_resume_rejects_changed_config_source_binding_and_nonempty_new_run(tmp_path):
    from diffphys.experimental.continuous_training import run
    seed = donor(tmp_path/'donor.pt')
    work = tmp_path/'run'
    run(config(), work, donor=seed, stop_after=1)
    with pytest.raises(ValueError, match='binding'):
        run(replace(config(), horizon=4), work, resume=work/'latest.pt')
    with pytest.raises(ValueError, match='nonempty'):
        run(config(), work, donor=seed)
    saved = torch.load(work/'latest.pt', weights_only=True)
    saved['binding']['experimental_sources']['tampered'] = 'invalid'
    torch.save(saved, work/'bad.pt')
    with pytest.raises(ValueError, match='binding'):
        run(config(), work, resume=work/'bad.pt')


@pytest.mark.parametrize('scheme', ['C', 'P'])
@pytest.mark.parametrize('enabled', [False, True])
@pytest.mark.parametrize('failure', ['forward', 'backward', 'interrupt'])
def test_run_exception_restores_gc_hooks_and_learning_state(tmp_path, monkeypatch, enabled, failure, scheme):
    from diffphys.experimental import continuous_update
    from diffphys.experimental.continuous_training import run
    from diffphys.response_grad_probe import GroupGradientProbe
    seed = donor(tmp_path/'donor.pt')
    prior = torch.load(seed, weights_only=True)
    created = []
    original = GroupGradientProbe.__init__

    def track(self, *args, **kw):
        original(self, *args, **kw)
        created.append(self)

    monkeypatch.setattr(GroupGradientProbe, '__init__', track)

    def fail(*args, **kw):
        assert not gc.isenabled()
        if failure == 'interrupt':
            raise KeyboardInterrupt('injected')
        raise RuntimeError('injected')

    # Warmup is frozen, so inject only in the actual update helper.
    monkeypatch.setattr(continuous_update, 'backward_actor' if failure == 'backward' else 'collect_rollout', fail)
    entry = gc.isenabled()
    try:
        (gc.enable if enabled else gc.disable)()
        with pytest.raises((RuntimeError, KeyboardInterrupt), match='injected'):
            run(config(scheme), tmp_path/'run', donor=seed)
        assert gc.isenabled() == enabled
        assert all(p._closed and not p._tensor_handles and not p._payloads for p in created)
        saved = torch.load(tmp_path/'run/failure.pt', weights_only=True)
        exact(saved['model'], prior['model'])
        exact(saved['optimizer'], prior['optimizer'])
        assert saved['progress']['updates'] == 0
        assert saved['cleanup']['closed_probes']
        if scheme == 'P':
            assert saved['cleanup']['worker_closed']
            assert not Path(f'/proc/{saved["cleanup"]["worker_pid"]}').exists()
    finally:
        (gc.enable if entry else gc.disable)()


@pytest.mark.parametrize('scheme', ['C', 'P'])
def test_real_sigint_stops_at_update_boundary_and_restores_gc(tmp_path, scheme):
    seed = donor(tmp_path/'donor.pt')
    work = tmp_path/'interrupt'
    with (tmp_path/'child.log').open('w') as log:
        process = subprocess.Popen([
            sys.executable, 'tools/train_compiled_candidate.py', '--scheme', scheme, '--device', 'cpu',
            '--scenes', '128', '--horizon', '3', '--updates', '20',
            '--work-dir', str(work), '--donor', str(seed)], stdout=log, stderr=log)
        try:
            deadline = time.monotonic()+20
            while not (work/'history.jsonl').exists() and process.poll() is None:
                assert time.monotonic() < deadline
                time.sleep(.01)
            assert process.poll() is None
            process.send_signal(signal.SIGINT)
            assert process.wait(timeout=20) == 0
        finally:
            if process.poll() is None:
                process.kill()
                process.wait()
    saved = torch.load(work/'latest.pt', weights_only=True)
    assert 0 < saved['next_update'] < 20
    assert saved['progress']['status'] == 'interrupted'
    assert saved['cleanup']['gc_enabled'] == saved['cleanup']['entry_gc_enabled']
    assert saved['cleanup']['closed_probes']
    if scheme == 'P':
        assert saved['cleanup']['worker_closed']
        assert not Path(f'/proc/{saved["cleanup"]["worker_pid"]}').exists()


def test_offline_exact_gate_checks_tensor_bytes_including_signed_zero():
    from tools.verify_compiled_continuity import exact as exact_bytes
    positive = torch.tensor([0.])
    negative = torch.tensor([-0.])
    assert torch.equal(positive, negative)
    with pytest.raises(AssertionError, match='tensor mismatch'):
        exact_bytes(positive, negative)
    exact_bytes(torch.tensor(78951.), torch.tensor(78951.))
