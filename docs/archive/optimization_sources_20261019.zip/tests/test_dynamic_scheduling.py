"""Preserve compaction and exact updates while isolating scheduling changes."""
from __future__ import annotations

import copy
from dataclasses import fields, replace
import gc
import weakref

import pytest
import torch

from diffphys.env_raptor import RaptorSimulator
from diffphys.response_adjoints import collect_rollout, backward_actor
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ResponseMotorPolicy
from diffphys.response_task import TaskLossConfig, rollout


@pytest.mark.parametrize("device", ["cpu", "cuda"])
@pytest.mark.parametrize("time_decay", [0., 1.3])
def test_index_fill_keeps_active_failure_and_trajectories_bitwise(device, time_decay):
    if device == "cuda" and not torch.cuda.is_available():
        pytest.skip("CUDA unavailable")
    from diffphys.experimental.dynamic_scheduling import index_fill_rollout
    from test_masked_rollout import mixed_failures

    torch.manual_seed(41)
    simulator = RaptorSimulator()
    state = mixed_failures(simulator).to(device, torch.float64)
    actor = ResponseMotorPolicy().to(device=device, dtype=torch.float64)
    reference = rollout(actor, simulator, state, 6, time_decay=time_decay)
    actual = index_fill_rollout(actor, simulator, state, 6, time_decay=time_decay)
    for field in fields(reference):
        value = getattr(reference, field.name)
        if torch.is_tensor(value):
            assert torch.equal(getattr(actual, field.name), value), field.name
    for a, b in [(reference.end.physical, actual.end.physical),
                 (reference.end.policy, actual.end.policy)]:
        for field in fields(a):
            assert torch.equal(getattr(a, field.name), getattr(b, field.name)), field.name
    assert reference.valid.sum(0).tolist()[:3] == [0, 1, 2]


@pytest.mark.parametrize("enabled", [False, True])
@pytest.mark.parametrize("fail", [False, True])
def test_gc_deferral_restores_enabled_state_and_thresholds_on_exit(enabled, fail):
    from diffphys.experimental.dynamic_scheduling import defer_automatic_gc

    entry = gc.isenabled()
    thresholds = gc.get_threshold()
    try:
        (gc.enable if enabled else gc.disable)()
        try:
            with defer_automatic_gc(True):
                assert not gc.isenabled()
                assert gc.get_threshold() == thresholds
                if fail:
                    raise RuntimeError("exercise exceptional exit")
        except RuntimeError:
            assert fail
        assert gc.isenabled() == enabled
        assert gc.get_threshold() == thresholds
    finally:
        (gc.enable if entry else gc.disable)()


@pytest.mark.parametrize("failure", [None, "backward", "forward"])
def test_probe_cleanup_releases_payloads_hooks_and_probe_on_all_exits(monkeypatch, failure):
    from diffphys import response_adjoints
    from diffphys.response_grad_probe import GroupGradientProbe

    actor = ResponseMotorPolicy().double()
    simulator = RaptorSimulator()
    initial = simulator.reset(32, seed=7, horizon=2, dtype=torch.float64)
    groups = GroupBalanceConfig(max_groups=1, min_scenarios=32)
    loss = TaskLossConfig(.01, .01, 25.)
    created = []

    def observe_probe(*args):
        probe = GroupGradientProbe(*args)
        created.append(probe)
        return probe

    monkeypatch.setattr(response_adjoints, "GroupGradientProbe", observe_probe)
    hooks_before = [len(m._forward_hooks) for m in actor.modules()]
    if failure == "forward":
        def fail_step(*args):
            raise RuntimeError("injected forward failure")
        monkeypatch.setattr(simulator, "step", fail_step)
        with pytest.raises(RuntimeError, match="injected"):
            collect_rollout(actor, simulator, initial, loss, horizon=2, group_config=groups)
    else:
        record = collect_rollout(actor, simulator, initial, loss, horizon=2, group_config=groups)
        if failure == "backward":
            with torch.no_grad():
                next(actor.parameters()).add_(1)
            with pytest.raises(RuntimeError, match="parameters changed"):
                backward_actor(actor, simulator, record, loss)
        else:
            backward_actor(actor, simulator, record, loss)
        del record
    probe = created.pop()
    assert probe._closed and not probe._payloads and not probe._tensor_handles
    assert not probe._module_handles and probe._current_slots is None
    assert [len(m._forward_hooks) for m in actor.modules()] == hooks_before
    reference = weakref.ref(probe)
    del probe
    assert reference() is None


@pytest.mark.parametrize("defer_gc", [False, True])
def test_scheduled_update_keeps_group_gradients_and_persistent_adam_exact(tmp_path, defer_gc):
    from diffphys.experimental.dynamic_scheduling import collector_for, index_fill_rollout
    from diffphys.experimental.scheduled_update import complete_scheduled_update
    from diffphys.experimental.training_benchmark import complete_update
    from diffphys.response_training import capture_rng, restore_rng
    from test_training_benchmark import audit_for

    torch.manual_seed(43)
    base = ResponseMotorPolicy().double()
    base_optimizer = torch.optim.Adam(base.parameters(), lr=3e-4)
    for p in base.parameters():
        p.grad = torch.full_like(p, .01)
    base_optimizer.step()
    rng = capture_rng()
    values = []
    for index, helper in enumerate([complete_update, complete_scheduled_update]):
        actor = copy.deepcopy(base)
        optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
        optimizer.load_state_dict(copy.deepcopy(base_optimizer.state_dict()))
        restore_rng(rng)
        work = tmp_path/str(index)
        extra = {"defer_gc": defer_gc} if index else {}
        result = helper(actor, optimizer, RaptorSimulator(),
                        collector=collector_for(index_fill_rollout) if index else collect_rollout,
                        scenes=128, horizon=3, loss=TaskLossConfig(.01, .01, 25.),
                        groups=GroupBalanceConfig(max_groups=128, min_scenarios=1, layout="coverage128"),
                        audit=audit_for(work), progress={"updates": 0}, history=work/'history.jsonl', **extra)
        values.append((torch.cat([p.detach().flatten() for p in actor.parameters()]),
                       result['record'].probe.rows.clone(), copy.deepcopy(optimizer.state_dict())))
        assert gc.isenabled()
    assert torch.equal(values[0][0], values[1][0])
    assert torch.equal(values[0][1], values[1][1])
    for key, state in values[0][2]['state'].items():
        for name, value in state.items():
            assert torch.equal(value, values[1][2]['state'][key][name])


def test_scheduled_forward_exception_restores_gc_actor_adam_and_rng(tmp_path, monkeypatch):
    from diffphys.experimental.dynamic_scheduling import collector_for, index_fill_rollout
    from diffphys.experimental.scheduled_update import complete_scheduled_update
    from diffphys.response_training import capture_rng, model_hash
    from test_training_benchmark import audit_for

    actor = ResponseMotorPolicy().double()
    optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
    simulator = RaptorSimulator()
    original, rng = model_hash(actor), capture_rng()

    def fail_step(*args):
        assert not gc.isenabled()
        raise RuntimeError("injected scheduled forward failure")

    monkeypatch.setattr(simulator, "step", fail_step)
    with pytest.raises(RuntimeError, match="injected scheduled"):
        complete_scheduled_update(
            actor, optimizer, simulator, collector=collector_for(index_fill_rollout),
            scenes=128, horizon=2, loss=TaskLossConfig(.01, .01, 25.),
            groups=GroupBalanceConfig(max_groups=128, min_scenarios=1, layout="coverage128"),
            audit=audit_for(tmp_path), progress={"updates": 0}, history=tmp_path/'history.jsonl',
            defer_gc=True)
    assert gc.isenabled() and model_hash(actor) == original
    assert not optimizer.state and torch.equal(torch.get_rng_state(), rng['torch'])
