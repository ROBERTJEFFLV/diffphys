from __future__ import annotations

import copy

import pytest
import torch

from diffphys.env_raptor import RaptorSimulator
from diffphys.response_adjoints import collect_rollout
from diffphys.response_audit import AuditConfig, UpdateAudit
from diffphys.response_groups import GroupBalanceConfig
from diffphys.response_policy import ResponseMotorPolicy
from diffphys.response_task import TaskLossConfig
from diffphys.response_training import atomic_json, atomic_torch, model_hash


def audit_for(path):
    return UpdateAudit(path, AuditConfig(), evaluation_interval=50, binding={"experiment": "unit"},
                       source_root=".", source_files=("diffphys/experimental/training_benchmark.py",),
                       torch_writer=atomic_torch, json_writer=atomic_json)


def test_complete_update_contains_persistent_adam_audit_history_and_sampling(tmp_path):
    from diffphys.experimental.training_benchmark import complete_update
    from diffphys.experimental.masked_rollout import collect_masked_rollout

    torch.manual_seed(27)
    base = ResponseMotorPolicy().double()
    adam = torch.optim.Adam(base.parameters(), lr=3e-4)
    for p in base.parameters():
        p.grad = torch.full_like(p, .01)
    adam.step()
    states = []
    for name, collector in (("dynamic", collect_rollout), ("mask", collect_masked_rollout)):
        actor = copy.deepcopy(base)
        optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
        optimizer.load_state_dict(copy.deepcopy(adam.state_dict()))
        work = tmp_path / name
        result = complete_update(actor, optimizer, RaptorSimulator(), collector=collector,
                                 scenes=128, horizon=2, loss=TaskLossConfig(.01, .01, 25.),
                                 groups=GroupBalanceConfig(max_groups=128, min_scenarios=1, layout="coverage128"),
                                 audit=audit_for(work), progress={"updates": 0},
                                 history=work / "measurements.jsonl")
        assert result["timings"]["complete_update_seconds"] > result["timings"]["forward_seconds"] > 0
        assert result["record"].metrics["physical_transitions"] == 256
        capsule = torch.load(work / result["audit_path"], weights_only=True)
        assert all(s["step"].item() == 2 for s in capsule["after"]["optimizer"]["state"].values())
        assert all(s["step"].item() == 1 for s in capsule["before"]["optimizer"]["state"].values())
        assert (work / "measurements.jsonl").read_text().count("\n") == 1
        assert result["timings"]["audit_seconds"] > 0
        assert result["timings"]["report_and_history_seconds"] > 0
        states.append((actor, optimizer, result["record"].probe.rows))
    for a, b in zip(states[0][0].parameters(), states[1][0].parameters()):
        torch.testing.assert_close(a, b, rtol=3e-9, atol=2e-10)
    torch.testing.assert_close(states[0][2], states[1][2], rtol=3e-9, atol=2e-10)


def test_complete_update_rolls_back_actor_adam_and_rng_on_audit_failure(tmp_path):
    from diffphys.experimental.training_benchmark import complete_update

    actor = ResponseMotorPolicy().double()
    optimizer = torch.optim.Adam(actor.parameters(), lr=3e-4)
    original = model_hash(actor)
    rng = torch.get_rng_state().clone()

    class BrokenAudit:
        def record(self, **kwargs):
            raise OSError("deliberate audit failure")

    with pytest.raises(OSError, match="deliberate audit failure"):
        complete_update(actor, optimizer, RaptorSimulator(), collector=collect_rollout,
                        scenes=128, horizon=1, loss=TaskLossConfig(.01, .01, 25.),
                        groups=GroupBalanceConfig(max_groups=128, min_scenarios=1, layout="coverage128"),
                        audit=BrokenAudit(), progress={"updates": 0}, history=tmp_path / "history.jsonl")
    assert model_hash(actor) == original
    assert optimizer.state_dict()["state"] == {}
    assert torch.equal(torch.get_rng_state(), rng)
