from tools.profile_rollout_scheduling import activity_window, merge_intervals


def test_profile_activity_uses_union_and_clips_overlapping_kernels():
    assert merge_intervals([(0, 4), (2, 7), (9, 12)]) == [(0, 7), (9, 12)]
    # Nsight timestamps are nanoseconds; only [1,10] ms belongs to this phase.
    activities = [(0, 4_000_000, 1, "kernel"), (2_000_000, 7_000_000, 2, "kernel"),
                  (9_000_000, 12_000_000, 3, "memcpy")]
    result = activity_window(1_000_000, 10_000_000, activities, {3: (8_000_000, 8_100_000)})
    assert result["wall_ms"] == 9
    assert result["all_gpu_activity_ms"] == 7
    assert result["kernel_active_ms"] == 6
    assert result["no_traced_activity_ms"] == 2
    assert result["host_late_submission_ms"] == 1
    assert result["gap_count"] == 1
    with_gc = activity_window(1_000_000, 10_000_000, activities, {},
                              gc_intervals=[(3_000_000, 8_000_000)])
    assert with_gc["gc_overlap_no_gpu_work_ms"] == 1


def test_profile_empty_window_is_not_reported_as_observed_gpu_occupancy():
    result = activity_window(0, 2_000_000, [], {})
    assert result["no_traced_activity_ms"] == 2
    assert result["host_late_submission_ms"] == 0
    assert result["activity_count"] == 0
